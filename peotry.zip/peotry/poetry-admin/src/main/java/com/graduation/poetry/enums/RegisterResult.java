package com.graduation.poetry.enums;

import com.graduation.poetry.common.api.IErrorCode;

public enum RegisterResult implements IErrorCode {
    REG_SUCCESS(0, "注册成功"),
    USERNAME_EXIST(1, "该用户名已经存在"),
    NAME_PASSWORD_NULL(2,"用户名或密码为空"),
    NAME_PASSWORD_TOO_LONG(3,"用户或密码过长"),//账号密码长度都不大于10
    REG_FAILED(4, "用户注册失败");

    private long code;
    private String message;

    RegisterResult(long code, String message){
        this.code =code;
        this.message = message;
    }
    @Override
    public long getCode() {
        return code;
    }

    @Override
    public String getMessage() {
        return message;
    }
}

