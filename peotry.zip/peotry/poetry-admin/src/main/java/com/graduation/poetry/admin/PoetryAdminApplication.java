package com.graduation.poetry.admin;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;

@SpringBootApplication(scanBasePackages = "com.graduation.poetry")
@MapperScan(basePackages = {"com.graduation.poetry.mapper","com.graduation.poetry.portal.dao"})

public class PoetryAdminApplication {
    public static void main(String[] args) {
        SpringApplication.run(PoetryAdminApplication.class,args);
    }
}
