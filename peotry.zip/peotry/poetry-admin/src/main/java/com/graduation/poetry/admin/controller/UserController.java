package com.graduation.poetry.admin.controller;


import com.graduation.poetry.admin.model.dto.UserRegisterParam;
import com.graduation.poetry.admin.service.UserService;
import com.graduation.poetry.common.api.CommonResult;
import com.graduation.poetry.enums.RegisterResult;
import com.graduation.poetry.model.PoetryDiscuss;
import com.graduation.poetry.model.User;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@CrossOrigin
@Api(value = "UserController",description = "用户接口")
@RestController
@RequestMapping("/user")
public class UserController {
    @Autowired
    private UserService userService;


    @ApiOperation("管理员注册")
    @PostMapping("/register")
    public CommonResult<Integer> register(@ApiParam("注册对象") @RequestBody UserRegisterParam param){
        System.out.println("------------------------------------------");
        RegisterResult register = userService.register(param);
        if (register == RegisterResult.REG_SUCCESS){
            return CommonResult.success(1,register.getMessage());
        }
        return CommonResult.failed(register.getMessage());
    }

    @ApiOperation("管理员登录")
    @PostMapping("/login")
    public CommonResult<Map<String,String>> login(@ApiParam("用户名")@RequestParam("userName") String userName,
                                                  @ApiParam("密码")@RequestParam("password") String password){
        Map<String,String> login = userService.login(userName,password);
        if(!CollectionUtils.isEmpty(login)){
            return CommonResult.success(login,"登录成功");
        }
        return CommonResult.failed("登录失败");

    }



}
