package com.graduation.poetry.admin.config;

import com.graduation.poetry.admin.model.PortalUserDetails;
import com.graduation.poetry.admin.service.UserService;
import com.graduation.poetry.model.User;
import com.graduation.poetry.security.config.SecurityConfig;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

@EnableWebSecurity
@Configuration
public class PortalSecurityConfig extends SecurityConfig{
    @Autowired
    private UserService userService;
    @Bean
    @Override
    protected UserDetailsService userDetailsService() {
        return new UserDetailsService() {
            @Override
            public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
                User user= userService.getUserByUsername(username);

                if( user != null){
                    return new PortalUserDetails(user);
                }
                return null;
            }
        };
    }
}
