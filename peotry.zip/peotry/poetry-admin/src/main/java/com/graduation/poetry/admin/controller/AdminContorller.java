package com.graduation.poetry.admin.controller;


import com.graduation.poetry.admin.service.AdminService;
import com.graduation.poetry.common.api.CommonResult;
import com.graduation.poetry.model.PoetryDiscuss;
import com.graduation.poetry.model.User;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.models.auth.In;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.parameters.P;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin
@Api(value = "AdminController",description = "管理接口")
@RestController
@RequestMapping("/admin")
public class AdminContorller {

    @Autowired
    private AdminService adminService;

    @ApiOperation("获取评论列表")
    @PostMapping("/getCommentList")
    public CommonResult<List<PoetryDiscuss>> getCommentList(@ApiParam("第几页")@RequestParam("pageNum") int pageNum,
                                                            @ApiParam("每一页有几个数据")@RequestParam("pageSize") int pageSize){
        List<PoetryDiscuss> commentList = adminService.getCommentList(pageNum, pageSize);
        if(commentList.size()>0){
            return CommonResult.success(commentList,"查询成功");
        }
        return CommonResult.failed("暂无评论");

    }

    @ApiOperation("获取用户列表")
    @PostMapping("/getUserList")
    public CommonResult<List<User>> getUserList(@ApiParam("第几页")@RequestParam("pageNum")int pageNum,
                                                @ApiParam("每一页有几个数据")@RequestParam("pageSize")int pageSize){
        List<User> userList = adminService.getUserList(pageNum, pageSize);
        if(userList.size()>0){
            return  CommonResult.success(userList,"查询成功");

        }
        return CommonResult.failed("暂无用户");
    }

    @ApiOperation("删除评论接口")
    @PostMapping("/deleteComment")
    public CommonResult<Integer> deleteComment(@ApiParam("评论id")@RequestParam("commentId") Long commentId)
    {
        int i = adminService.deleteComment(commentId);
        if (i == 1) {
            return CommonResult.success(1,"删除成功");
        }
        return CommonResult.failed("删除失败");
    }


    @ApiOperation("封禁用户账号接口")
    @PostMapping("/bannedUser")
    public CommonResult<Integer> bannedUser(@ApiParam("用户id")@RequestParam("userId") Long userId){
        int i = adminService.bannedUser(userId);
        if(i==1){
            return CommonResult.success(1,"封号成功");
        }
        return CommonResult.failed("封号失败");
    }


    @ApiOperation("返回被举报的评论列表")
    @GetMapping("/getReportCommentList")
    public CommonResult<List<PoetryDiscuss>> getReportCommentList(){
        List<PoetryDiscuss> reportCommentList = adminService.getReportCommentList();
        if(reportCommentList.size()>0){
            return CommonResult.success(reportCommentList,"返回成功");
        }
        return CommonResult.failed("查找失败");
    }

    @ApiOperation("返回被举报的用户")
    @GetMapping("/getReportUserList")
    public CommonResult<List<User>> getReportUserList(){
        List<User> reportUserList = adminService.getReportUserList();
        if(reportUserList.size()>0){
            return CommonResult.success(reportUserList,"返回成功");
        }
        return CommonResult.failed("查找失败");
    }


    @ApiOperation("解除用户被举报的状态")
    @PostMapping("/relieveUserReport")
    public CommonResult<Integer> relieveUserReport(@ApiParam("用户id")@RequestParam("userId")Long userId){
        int i = adminService.relieveUserReport(userId);
        if(i==1){
            return CommonResult.success(1,"解除成功");
        }
        return CommonResult.failed("解除失败");
    }

    @ApiOperation("解除评论被举报的状态")
    @PostMapping("/relieveCommentReport")
    public CommonResult<Integer> relieveCommentReport(@ApiParam("评论id")@RequestParam("commentId")Long commend){
        int i = adminService.relieveCommentReport(commend);
        if(i==1){
            return CommonResult.success(1,"解除成功");
        }
        return CommonResult.failed("解除失败");
    }

}
