package com.graduation.poetry.admin.service.Impl;

import com.github.pagehelper.PageHelper;
import com.graduation.poetry.admin.service.AdminService;
import com.graduation.poetry.mapper.PoetryDiscussMapper;
import com.graduation.poetry.mapper.UserMapper;
import com.graduation.poetry.model.PoetryDiscuss;
import com.graduation.poetry.model.PoetryDiscussExample;
import com.graduation.poetry.model.User;
import com.graduation.poetry.model.UserExample;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AdminServiceImpl implements AdminService {
    @Autowired
    private PoetryDiscussMapper poetryDiscussMapper;
    @Autowired
    private UserMapper userMapper;

    //返回所有评论
    @Override
    public List<PoetryDiscuss> getCommentList(int pageNum, int pageSize) {
        //分页插件
        PageHelper.startPage(pageNum,pageSize);
        PoetryDiscussExample poetryDiscussExample = new PoetryDiscussExample();
        poetryDiscussExample.createCriteria().andIsDeleteNotEqualTo(1);
        List<PoetryDiscuss> poetryDiscusses = poetryDiscussMapper.selectByExample(poetryDiscussExample);

        return poetryDiscusses;
    }

    @Override
    public List<User> getUserList(int pageNum, int pageSize) {
        PageHelper.startPage(pageNum,pageSize);
        UserExample example = new UserExample();
        example.createCriteria().andIsManagerNotEqualTo(1).andIsBannedLoginNotEqualTo(1);
        List<User> users = userMapper.selectByExample(example);
        System.out.println(users);
        return users;
    }

    //删除评论
    @Override
    public int deleteComment(Long commentId) {
        PoetryDiscuss poetryDiscuss = new PoetryDiscuss();
        poetryDiscuss.setId(commentId);
        poetryDiscuss.setIsDelete(1);
        if(poetryDiscussMapper.updateByPrimaryKeySelective(poetryDiscuss)>0)
        {
            return 1;
        }
        return 0;
    }

    //封禁用户账号
    @Override
    public int bannedUser(Long userId) {
        User user = new User();
        user.setId(userId);
        user.setIsBannedLogin(1);
        if(userMapper.updateByPrimaryKeySelective(user)>0)
        {
            return 1;
        }
        return 0;
    }
    //返回被举报评论

    @Override
    public List<PoetryDiscuss> getReportCommentList() {
        PoetryDiscussExample poetryDiscussExample = new PoetryDiscussExample();
        poetryDiscussExample.createCriteria().andBeReportEqualTo(1).andIsDeleteNotEqualTo(1);
        List<PoetryDiscuss> poetryDiscusses = poetryDiscussMapper.selectByExample(poetryDiscussExample);

        return poetryDiscusses;
    }


    //返回被举报用户


    @Override
    public List<User> getReportUserList() {
        UserExample example = new UserExample();
        example.createCriteria().andBeReportEqualTo(1).andIsBannedLoginNotEqualTo(1);
        List<User> users = userMapper.selectByExample(example);

        return users;
    }



    @Override
    public int relieveUserReport(Long userId) {
        User user = new User();
        user.setId(userId);
        user.setBeReport(2);
        if(userMapper.updateByPrimaryKeySelective(user)>0){
            return 1;
        }
        return 0;
    }

    @Override
    public int relieveCommentReport(Long commentId) {
        PoetryDiscuss poetryDiscuss = new PoetryDiscuss();
        poetryDiscuss.setId(commentId);
        poetryDiscuss.setBeReport(2);
        if(poetryDiscussMapper.updateByPrimaryKeySelective(poetryDiscuss)>0)
        {
            return 1;
        }
        return 0;
    }
}
