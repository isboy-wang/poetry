package com.graduation.poetry.admin.service.Impl;

import com.github.pagehelper.PageHelper;
import com.graduation.poetry.admin.model.dto.UserRegisterParam;
import com.graduation.poetry.admin.service.UserService;
import com.graduation.poetry.enums.RegisterResult;
import com.graduation.poetry.mapper.PoetryDiscussMapper;
import com.graduation.poetry.mapper.UserMapper;
import com.graduation.poetry.model.PoetryDiscuss;
import com.graduation.poetry.model.PoetryDiscussExample;
import com.graduation.poetry.model.User;
import com.graduation.poetry.model.UserExample;
import com.graduation.poetry.security.util.JwtTokenUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class UserServiceImpl implements UserService {

    public static final Logger logger = LoggerFactory.getLogger(UserServiceImpl.class);

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private JwtTokenUtil jwtTokenUtil;

    @Autowired
    private PoetryDiscussMapper poetryDiscussMapper;
    @Autowired
    private UserMapper userMapper;

    @Autowired
    private PasswordEncoder passwordEncoder;


    //注册
    @Override
    public RegisterResult register(UserRegisterParam userRegisterParam) {
        UserExample example = new UserExample();
        example.createCriteria().andUserNameEqualTo(userRegisterParam.getUserName());
        //如果账号密码为空
        if(userRegisterParam.getUserName() == null || userRegisterParam.getPassword() == null){
            return RegisterResult.NAME_PASSWORD_NULL;
        }
        //如果用户名存在
        if(userMapper.countByExample(example) > 0){
            return RegisterResult.USERNAME_EXIST;
        }
        //如果账号密码过长(账号密码长度都不大于10)

        if(userRegisterParam.getUserName().length() >= 10 || userRegisterParam.getPassword().length()>10){
            return RegisterResult.NAME_PASSWORD_TOO_LONG;
        }
        User user = new User();
        user.setUserName(userRegisterParam.getUserName());
        user.setPassword(passwordEncoder.encode(userRegisterParam.getPassword()));
        user.setPhone(userRegisterParam.getPhone());
        user.setIsBannedLogin(2);

        user.setIsManager(1);
//        user.setBirthday(userRegisterParam.getBirthday());
        if(userMapper.insertSelective(user) > 0){
            return RegisterResult.REG_SUCCESS;
        }
        return RegisterResult.REG_FAILED;
    }
    //登录
    @Override
    public Map<String, String> login(String userName, String password) {
        UsernamePasswordAuthenticationToken token = new UsernamePasswordAuthenticationToken(userName, password);
        Authentication authentication = null;
        UserExample example = new UserExample();
        example.createCriteria().andUserNameEqualTo(userName);
        List<User> users = userMapper.selectByExample(example);

        if(users.size()>0 && users.get(0).getIsManager()==2){
            Map<String,String> map = new HashMap<>();
            return map;
        }
        //验证token
        try{
            authentication = authenticationManager.authenticate(token);
        }catch (AuthenticationException e){
            logger.error("用户名或密码错误"+e);
        }

//        SecurityContextHolder.getContext().setAuthentication(authenticate);
        SecurityContextHolder.getContext().setAuthentication(authentication);

        Map<String,String> tokenMap = new HashMap<>();
        if(authentication != null)
        {
            //通过验证返回的authenticate中获取userDetails
            UserDetails userDetails =(UserDetails) authentication.getPrincipal();
            //根据userDetailis生成token字符串
            String tokenString = jwtTokenUtil.generateToken(userDetails);
            tokenMap.put("token",tokenString);
            tokenMap.put("tokenHead",jwtTokenUtil.getTokenHead());
            tokenMap.put("tokenHeader",jwtTokenUtil.getTokenHeader());

        }


        return tokenMap;
    }


    @Override
    public User getUserByUsername(String userName) {

        UserExample example = new UserExample();
        example.createCriteria().andUserNameEqualTo(userName);
        List<User> users = userMapper.selectByExample(example);

//        if(users != null && users.size()>0){}
        if(!CollectionUtils.isEmpty(users)){
            return users.get(0);
        }

        return null;
    }


}
