package com.graduation.poetry.admin.service;

import com.graduation.poetry.admin.model.dto.UserRegisterParam;
import com.graduation.poetry.enums.RegisterResult;
import com.graduation.poetry.model.PoetryDiscuss;
import com.graduation.poetry.model.User;

import java.util.List;
import java.util.Map;

public interface UserService {


    /**
     *   根据注册类注册
     * @param userRegisterParam
     * @return 返回结果枚举
     */
    RegisterResult register(UserRegisterParam userRegisterParam);

    /**
     * 根据用户名密码登录
     * @param userName
     * @param password
     * @return 返回键值对数组（Map）
     */
    Map<String,String> login(String userName, String password);
    /**
     *根据用户名返回用户
     * @param userName
     * @return
     */
    User getUserByUsername(String userName);




}
