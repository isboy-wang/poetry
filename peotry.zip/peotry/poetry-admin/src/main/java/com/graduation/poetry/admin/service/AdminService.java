package com.graduation.poetry.admin.service;

import com.graduation.poetry.model.PoetryDiscuss;
import com.graduation.poetry.model.User;

import java.util.List;

public interface AdminService {

    /**
     * 获取评论列表
     * @param pageNum 第几页
     * @param pageSize 每一页的评论数
     * @return return 返回分页列表
     */
    List<PoetryDiscuss> getCommentList(int pageNum, int pageSize);

    /**
     * 获取所有诗词
     * @param pageNum
     * @param pageSize
     * @return
     */
    List<User> getUserList(int pageNum,int pageSize);


    /**
     * 删除诗词
     * @param commentId 诗词id
     * @return 成功返回1，失败返回0
     */
    int deleteComment(Long commentId);


    /**
     * 封禁用户账号
     * @param userId 诗词id
     * @return 成功返回1，失败返回0
     */
    int bannedUser(Long userId);

    /**
     * 获取被举报评论的列表
     * @return 评论列表
     */
    List<PoetryDiscuss> getReportCommentList();

    /**
     * 获取被举报用户列表
     * @return 用户列表
     */
    List<User> getReportUserList();


    /**
     * 解除用户被举报状态
     * @param userId 用户id
     * @return 成功返回1失败返回0
     */
    int relieveUserReport(Long userId);

    /**
     * 解除评论被举报状态
     * @param commentId 评论id
     * @return 成功返回1，失败返回0
     */
    int relieveCommentReport(Long commentId);

}

