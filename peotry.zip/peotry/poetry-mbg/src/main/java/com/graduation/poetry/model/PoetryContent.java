package com.graduation.poetry.model;

import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;
import java.util.Date;

public class PoetryContent implements Serializable {
    @ApiModelProperty(value = "唯一标识")
    private Long id;

    @ApiModelProperty(value = "诗词作者id")
    private Long authorId;

    @ApiModelProperty(value = "作者名字")
    private String author;

    @ApiModelProperty(value = "诗词名字")
    private String poetryName;

    @ApiModelProperty(value = "诗词内容")
    private String poetryContent;

    @ApiModelProperty(value = "诗词翻译")
    private String poetryTranslate;

    @ApiModelProperty(value = "诗词注释")
    private String poetryAnnotation;

    @ApiModelProperty(value = "创作背景")
    private String poetryBackground;

    @ApiModelProperty(value = "修改时间")
    private Date updateTime;

    @ApiModelProperty(value = "创建时间")
    private Date createTime;

    private static final long serialVersionUID = 1L;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getAuthorId() {
        return authorId;
    }

    public void setAuthorId(Long authorId) {
        this.authorId = authorId;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getPoetryName() {
        return poetryName;
    }

    public void setPoetryName(String poetryName) {
        this.poetryName = poetryName;
    }

    public String getPoetryContent() {
        return poetryContent;
    }

    public void setPoetryContent(String poetryContent) {
        this.poetryContent = poetryContent;
    }

    public String getPoetryTranslate() {
        return poetryTranslate;
    }

    public void setPoetryTranslate(String poetryTranslate) {
        this.poetryTranslate = poetryTranslate;
    }

    public String getPoetryAnnotation() {
        return poetryAnnotation;
    }

    public void setPoetryAnnotation(String poetryAnnotation) {
        this.poetryAnnotation = poetryAnnotation;
    }

    public String getPoetryBackground() {
        return poetryBackground;
    }

    public void setPoetryBackground(String poetryBackground) {
        this.poetryBackground = poetryBackground;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", id=").append(id);
        sb.append(", authorId=").append(authorId);
        sb.append(", author=").append(author);
        sb.append(", poetryName=").append(poetryName);
        sb.append(", poetryContent=").append(poetryContent);
        sb.append(", poetryTranslate=").append(poetryTranslate);
        sb.append(", poetryAnnotation=").append(poetryAnnotation);
        sb.append(", poetryBackground=").append(poetryBackground);
        sb.append(", updateTime=").append(updateTime);
        sb.append(", createTime=").append(createTime);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }
}