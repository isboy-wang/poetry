package com.graduation.poetry.mapper;

import com.graduation.poetry.model.PoetryContent;
import com.graduation.poetry.model.PoetryContentExample;
import java.util.List;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface PoetryContentMapper {
    long countByExample(PoetryContentExample example);

    int deleteByExample(PoetryContentExample example);

    int deleteByPrimaryKey(Long id);

    int insert(PoetryContent record);

    int insertSelective(PoetryContent record);

    List<PoetryContent> selectByExample(PoetryContentExample example);

    PoetryContent selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") PoetryContent record, @Param("example") PoetryContentExample example);

    int updateByExample(@Param("record") PoetryContent record, @Param("example") PoetryContentExample example);

    int updateByPrimaryKeySelective(PoetryContent record);

    int updateByPrimaryKey(PoetryContent record);
}