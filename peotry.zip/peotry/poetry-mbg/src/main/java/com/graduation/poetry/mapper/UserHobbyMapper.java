package com.graduation.poetry.mapper;

import com.graduation.poetry.model.UserHobby;
import com.graduation.poetry.model.UserHobbyExample;
import java.util.List;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface UserHobbyMapper {
    long countByExample(UserHobbyExample example);

    int deleteByExample(UserHobbyExample example);

    int deleteByPrimaryKey(Long id);

    int insert(UserHobby record);

    int insertSelective(UserHobby record);

    List<UserHobby> selectByExample(UserHobbyExample example);

    UserHobby selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") UserHobby record, @Param("example") UserHobbyExample example);

    int updateByExample(@Param("record") UserHobby record, @Param("example") UserHobbyExample example);

    int updateByPrimaryKeySelective(UserHobby record);

    int updateByPrimaryKey(UserHobby record);
}