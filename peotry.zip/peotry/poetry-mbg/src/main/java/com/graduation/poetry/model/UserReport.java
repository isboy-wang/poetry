package com.graduation.poetry.model;

import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;
import java.util.Date;

public class UserReport implements Serializable {
    private Long id;

    @ApiModelProperty(value = "被举报用户id")
    private Long beReportUserId;

    @ApiModelProperty(value = "举报发起用户id")
    private Long reportUserId;

    @ApiModelProperty(value = "举报理由（简介）")
    private String reportIntroduce;

    @ApiModelProperty(value = "创建时间（举报时间）")
    private Date createTime;

    @ApiModelProperty(value = "修改时间")
    private Date updateTime;

    @ApiModelProperty(value = "是否处理（1为是，2为否）")
    private Integer isDispose;

    private static final long serialVersionUID = 1L;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getBeReportUserId() {
        return beReportUserId;
    }

    public void setBeReportUserId(Long beReportUserId) {
        this.beReportUserId = beReportUserId;
    }

    public Long getReportUserId() {
        return reportUserId;
    }

    public void setReportUserId(Long reportUserId) {
        this.reportUserId = reportUserId;
    }

    public String getReportIntroduce() {
        return reportIntroduce;
    }

    public void setReportIntroduce(String reportIntroduce) {
        this.reportIntroduce = reportIntroduce;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Integer getIsDispose() {
        return isDispose;
    }

    public void setIsDispose(Integer isDispose) {
        this.isDispose = isDispose;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", id=").append(id);
        sb.append(", beReportUserId=").append(beReportUserId);
        sb.append(", reportUserId=").append(reportUserId);
        sb.append(", reportIntroduce=").append(reportIntroduce);
        sb.append(", createTime=").append(createTime);
        sb.append(", updateTime=").append(updateTime);
        sb.append(", isDispose=").append(isDispose);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }
}