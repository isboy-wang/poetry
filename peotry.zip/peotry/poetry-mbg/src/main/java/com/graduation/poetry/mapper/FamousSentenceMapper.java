package com.graduation.poetry.mapper;

import com.graduation.poetry.model.FamousSentence;
import com.graduation.poetry.model.FamousSentenceExample;
import java.util.List;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface FamousSentenceMapper {
    long countByExample(FamousSentenceExample example);

    int deleteByExample(FamousSentenceExample example);

    int deleteByPrimaryKey(Long id);

    int insert(FamousSentence record);

    int insertSelective(FamousSentence record);

    List<FamousSentence> selectByExample(FamousSentenceExample example);

    FamousSentence selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") FamousSentence record, @Param("example") FamousSentenceExample example);

    int updateByExample(@Param("record") FamousSentence record, @Param("example") FamousSentenceExample example);

    int updateByPrimaryKeySelective(FamousSentence record);

    int updateByPrimaryKey(FamousSentence record);
}