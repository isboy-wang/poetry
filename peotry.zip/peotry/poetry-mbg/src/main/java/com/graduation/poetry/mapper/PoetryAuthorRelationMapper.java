package com.graduation.poetry.mapper;

import com.graduation.poetry.model.PoetryAuthorRelation;
import com.graduation.poetry.model.PoetryAuthorRelationExample;
import java.util.List;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface PoetryAuthorRelationMapper {
    long countByExample(PoetryAuthorRelationExample example);

    int deleteByExample(PoetryAuthorRelationExample example);

    int deleteByPrimaryKey(Long id);

    int insert(PoetryAuthorRelation record);

    int insertSelective(PoetryAuthorRelation record);

    List<PoetryAuthorRelation> selectByExample(PoetryAuthorRelationExample example);

    PoetryAuthorRelation selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") PoetryAuthorRelation record, @Param("example") PoetryAuthorRelationExample example);

    int updateByExample(@Param("record") PoetryAuthorRelation record, @Param("example") PoetryAuthorRelationExample example);

    int updateByPrimaryKeySelective(PoetryAuthorRelation record);

    int updateByPrimaryKey(PoetryAuthorRelation record);
}