package com.graduation.poetry.model;

import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;
import java.util.Date;

public class User implements Serializable {
    private Long id;

    @ApiModelProperty(value = "用户名")
    private String userName;

    @ApiModelProperty(value = "用户密码")
    private String password;

    @ApiModelProperty(value = "用户性别，零表示女，1表示男")
    private Integer gender;

    @ApiModelProperty(value = "个人简介")
    private String userIntroduce;

    @ApiModelProperty(value = "用户头像路径")
    private String imgUrl;

    @ApiModelProperty(value = "学历")
    private String educationBackground;

    @ApiModelProperty(value = "真实姓名")
    private String realName;

    @ApiModelProperty(value = "手机号")
    private String phone;

    @ApiModelProperty(value = "生日")
    private String birthday;

    @ApiModelProperty(value = "住址")
    private String address;

    @ApiModelProperty(value = "创建时间（注册时间）")
    private Date createTime;

    @ApiModelProperty(value = "修改时间")
    private Date updateTime;

    @ApiModelProperty(value = "微信号")
    private String wechat;

    @ApiModelProperty(value = "qq号")
    private String qq;

    @ApiModelProperty(value = "实名认证是否通过，通过为1，不通过为2，没通过不能发朗读，评论")
    private Integer realNameApproved;

    @ApiModelProperty(value = "职业")
    private String occupation;

    @ApiModelProperty(value = "是否被举报（1为是，2为否）")
    private Integer beReport;

    @ApiModelProperty(value = "是否被禁言（1为是，2为否)")
    private Integer isBannedTalk;

    @ApiModelProperty(value = "是否为封号（1为是，2为否）")
    private Integer isBannedLogin;

    @ApiModelProperty(value = "是否为管理员（1是，2为否）")
    private Integer isManager;

    private static final long serialVersionUID = 1L;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Integer getGender() {
        return gender;
    }

    public void setGender(Integer gender) {
        this.gender = gender;
    }

    public String getUserIntroduce() {
        return userIntroduce;
    }

    public void setUserIntroduce(String userIntroduce) {
        this.userIntroduce = userIntroduce;
    }

    public String getImgUrl() {
        return imgUrl;
    }

    public void setImgUrl(String imgUrl) {
        this.imgUrl = imgUrl;
    }

    public String getEducationBackground() {
        return educationBackground;
    }

    public void setEducationBackground(String educationBackground) {
        this.educationBackground = educationBackground;
    }

    public String getRealName() {
        return realName;
    }

    public void setRealName(String realName) {
        this.realName = realName;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getBirthday() {
        return birthday;
    }

    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public String getWechat() {
        return wechat;
    }

    public void setWechat(String wechat) {
        this.wechat = wechat;
    }

    public String getQq() {
        return qq;
    }

    public void setQq(String qq) {
        this.qq = qq;
    }

    public Integer getRealNameApproved() {
        return realNameApproved;
    }

    public void setRealNameApproved(Integer realNameApproved) {
        this.realNameApproved = realNameApproved;
    }

    public String getOccupation() {
        return occupation;
    }

    public void setOccupation(String occupation) {
        this.occupation = occupation;
    }

    public Integer getBeReport() {
        return beReport;
    }

    public void setBeReport(Integer beReport) {
        this.beReport = beReport;
    }

    public Integer getIsBannedTalk() {
        return isBannedTalk;
    }

    public void setIsBannedTalk(Integer isBannedTalk) {
        this.isBannedTalk = isBannedTalk;
    }

    public Integer getIsBannedLogin() {
        return isBannedLogin;
    }

    public void setIsBannedLogin(Integer isBannedLogin) {
        this.isBannedLogin = isBannedLogin;
    }

    public Integer getIsManager() {
        return isManager;
    }

    public void setIsManager(Integer isManager) {
        this.isManager = isManager;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", id=").append(id);
        sb.append(", userName=").append(userName);
        sb.append(", password=").append(password);
        sb.append(", gender=").append(gender);
        sb.append(", userIntroduce=").append(userIntroduce);
        sb.append(", imgUrl=").append(imgUrl);
        sb.append(", educationBackground=").append(educationBackground);
        sb.append(", realName=").append(realName);
        sb.append(", phone=").append(phone);
        sb.append(", birthday=").append(birthday);
        sb.append(", address=").append(address);
        sb.append(", createTime=").append(createTime);
        sb.append(", updateTime=").append(updateTime);
        sb.append(", wechat=").append(wechat);
        sb.append(", qq=").append(qq);
        sb.append(", realNameApproved=").append(realNameApproved);
        sb.append(", occupation=").append(occupation);
        sb.append(", beReport=").append(beReport);
        sb.append(", isBannedTalk=").append(isBannedTalk);
        sb.append(", isBannedLogin=").append(isBannedLogin);
        sb.append(", isManager=").append(isManager);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }
}