package com.graduation.poetry.model;

import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;
import java.util.Date;

public class Message implements Serializable {
    @ApiModelProperty(value = "唯一标识")
    private Long id;

    @ApiModelProperty(value = "发送方id")
    private Long sendUserId;

    @ApiModelProperty(value = "接受方id")
    private Long receiveUserId;

    @ApiModelProperty(value = "创建时间")
    private Date createTime;

    @ApiModelProperty(value = "是否为分享诗词消息（是为1，不是为2）")
    private Integer isSharePoetry;

    @ApiModelProperty(value = "分享诗词的id")
    private Long sharePoetryId;

    @ApiModelProperty(value = "消息内容")
    private String messageContent;

    private static final long serialVersionUID = 1L;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getSendUserId() {
        return sendUserId;
    }

    public void setSendUserId(Long sendUserId) {
        this.sendUserId = sendUserId;
    }

    public Long getReceiveUserId() {
        return receiveUserId;
    }

    public void setReceiveUserId(Long receiveUserId) {
        this.receiveUserId = receiveUserId;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Integer getIsSharePoetry() {
        return isSharePoetry;
    }

    public void setIsSharePoetry(Integer isSharePoetry) {
        this.isSharePoetry = isSharePoetry;
    }

    public Long getSharePoetryId() {
        return sharePoetryId;
    }

    public void setSharePoetryId(Long sharePoetryId) {
        this.sharePoetryId = sharePoetryId;
    }

    public String getMessageContent() {
        return messageContent;
    }

    public void setMessageContent(String messageContent) {
        this.messageContent = messageContent;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", id=").append(id);
        sb.append(", sendUserId=").append(sendUserId);
        sb.append(", receiveUserId=").append(receiveUserId);
        sb.append(", createTime=").append(createTime);
        sb.append(", isSharePoetry=").append(isSharePoetry);
        sb.append(", sharePoetryId=").append(sharePoetryId);
        sb.append(", messageContent=").append(messageContent);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }
}