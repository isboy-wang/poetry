package com.graduation.poetry.mapper;

import com.graduation.poetry.model.UserPractice;
import com.graduation.poetry.model.UserPracticeExample;
import java.util.List;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface UserPracticeMapper {
    long countByExample(UserPracticeExample example);

    int deleteByExample(UserPracticeExample example);

    int deleteByPrimaryKey(Long id);

    int insert(UserPractice record);

    int insertSelective(UserPractice record);

    List<UserPractice> selectByExample(UserPracticeExample example);

    UserPractice selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") UserPractice record, @Param("example") UserPracticeExample example);

    int updateByExample(@Param("record") UserPractice record, @Param("example") UserPracticeExample example);

    int updateByPrimaryKeySelective(UserPractice record);

    int updateByPrimaryKey(UserPractice record);
}