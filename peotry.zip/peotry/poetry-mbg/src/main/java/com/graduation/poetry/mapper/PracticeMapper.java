package com.graduation.poetry.mapper;

import com.graduation.poetry.model.Practice;
import com.graduation.poetry.model.PracticeExample;
import java.util.List;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface PracticeMapper {
    long countByExample(PracticeExample example);

    int deleteByExample(PracticeExample example);

    int deleteByPrimaryKey(Long id);

    int insert(Practice record);

    int insertSelective(Practice record);

    List<Practice> selectByExample(PracticeExample example);

    Practice selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") Practice record, @Param("example") PracticeExample example);

    int updateByExample(@Param("record") Practice record, @Param("example") PracticeExample example);

    int updateByPrimaryKeySelective(Practice record);

    int updateByPrimaryKey(Practice record);
}