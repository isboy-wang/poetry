package com.graduation.poetry.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class PoetryDiscussExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public PoetryDiscussExample() {
        oredCriteria = new ArrayList<>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andIdIsNull() {
            addCriterion("id is null");
            return (Criteria) this;
        }

        public Criteria andIdIsNotNull() {
            addCriterion("id is not null");
            return (Criteria) this;
        }

        public Criteria andIdEqualTo(Long value) {
            addCriterion("id =", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotEqualTo(Long value) {
            addCriterion("id <>", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThan(Long value) {
            addCriterion("id >", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThanOrEqualTo(Long value) {
            addCriterion("id >=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThan(Long value) {
            addCriterion("id <", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThanOrEqualTo(Long value) {
            addCriterion("id <=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdIn(List<Long> values) {
            addCriterion("id in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotIn(List<Long> values) {
            addCriterion("id not in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdBetween(Long value1, Long value2) {
            addCriterion("id between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotBetween(Long value1, Long value2) {
            addCriterion("id not between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andPoetryDiscussIsNull() {
            addCriterion("poetry_discuss is null");
            return (Criteria) this;
        }

        public Criteria andPoetryDiscussIsNotNull() {
            addCriterion("poetry_discuss is not null");
            return (Criteria) this;
        }

        public Criteria andPoetryDiscussEqualTo(String value) {
            addCriterion("poetry_discuss =", value, "poetryDiscuss");
            return (Criteria) this;
        }

        public Criteria andPoetryDiscussNotEqualTo(String value) {
            addCriterion("poetry_discuss <>", value, "poetryDiscuss");
            return (Criteria) this;
        }

        public Criteria andPoetryDiscussGreaterThan(String value) {
            addCriterion("poetry_discuss >", value, "poetryDiscuss");
            return (Criteria) this;
        }

        public Criteria andPoetryDiscussGreaterThanOrEqualTo(String value) {
            addCriterion("poetry_discuss >=", value, "poetryDiscuss");
            return (Criteria) this;
        }

        public Criteria andPoetryDiscussLessThan(String value) {
            addCriterion("poetry_discuss <", value, "poetryDiscuss");
            return (Criteria) this;
        }

        public Criteria andPoetryDiscussLessThanOrEqualTo(String value) {
            addCriterion("poetry_discuss <=", value, "poetryDiscuss");
            return (Criteria) this;
        }

        public Criteria andPoetryDiscussLike(String value) {
            addCriterion("poetry_discuss like", value, "poetryDiscuss");
            return (Criteria) this;
        }

        public Criteria andPoetryDiscussNotLike(String value) {
            addCriterion("poetry_discuss not like", value, "poetryDiscuss");
            return (Criteria) this;
        }

        public Criteria andPoetryDiscussIn(List<String> values) {
            addCriterion("poetry_discuss in", values, "poetryDiscuss");
            return (Criteria) this;
        }

        public Criteria andPoetryDiscussNotIn(List<String> values) {
            addCriterion("poetry_discuss not in", values, "poetryDiscuss");
            return (Criteria) this;
        }

        public Criteria andPoetryDiscussBetween(String value1, String value2) {
            addCriterion("poetry_discuss between", value1, value2, "poetryDiscuss");
            return (Criteria) this;
        }

        public Criteria andPoetryDiscussNotBetween(String value1, String value2) {
            addCriterion("poetry_discuss not between", value1, value2, "poetryDiscuss");
            return (Criteria) this;
        }

        public Criteria andPoetryIdIsNull() {
            addCriterion("poetry_id is null");
            return (Criteria) this;
        }

        public Criteria andPoetryIdIsNotNull() {
            addCriterion("poetry_id is not null");
            return (Criteria) this;
        }

        public Criteria andPoetryIdEqualTo(Long value) {
            addCriterion("poetry_id =", value, "poetryId");
            return (Criteria) this;
        }

        public Criteria andPoetryIdNotEqualTo(Long value) {
            addCriterion("poetry_id <>", value, "poetryId");
            return (Criteria) this;
        }

        public Criteria andPoetryIdGreaterThan(Long value) {
            addCriterion("poetry_id >", value, "poetryId");
            return (Criteria) this;
        }

        public Criteria andPoetryIdGreaterThanOrEqualTo(Long value) {
            addCriterion("poetry_id >=", value, "poetryId");
            return (Criteria) this;
        }

        public Criteria andPoetryIdLessThan(Long value) {
            addCriterion("poetry_id <", value, "poetryId");
            return (Criteria) this;
        }

        public Criteria andPoetryIdLessThanOrEqualTo(Long value) {
            addCriterion("poetry_id <=", value, "poetryId");
            return (Criteria) this;
        }

        public Criteria andPoetryIdIn(List<Long> values) {
            addCriterion("poetry_id in", values, "poetryId");
            return (Criteria) this;
        }

        public Criteria andPoetryIdNotIn(List<Long> values) {
            addCriterion("poetry_id not in", values, "poetryId");
            return (Criteria) this;
        }

        public Criteria andPoetryIdBetween(Long value1, Long value2) {
            addCriterion("poetry_id between", value1, value2, "poetryId");
            return (Criteria) this;
        }

        public Criteria andPoetryIdNotBetween(Long value1, Long value2) {
            addCriterion("poetry_id not between", value1, value2, "poetryId");
            return (Criteria) this;
        }

        public Criteria andSupportNumIsNull() {
            addCriterion("support_num is null");
            return (Criteria) this;
        }

        public Criteria andSupportNumIsNotNull() {
            addCriterion("support_num is not null");
            return (Criteria) this;
        }

        public Criteria andSupportNumEqualTo(Long value) {
            addCriterion("support_num =", value, "supportNum");
            return (Criteria) this;
        }

        public Criteria andSupportNumNotEqualTo(Long value) {
            addCriterion("support_num <>", value, "supportNum");
            return (Criteria) this;
        }

        public Criteria andSupportNumGreaterThan(Long value) {
            addCriterion("support_num >", value, "supportNum");
            return (Criteria) this;
        }

        public Criteria andSupportNumGreaterThanOrEqualTo(Long value) {
            addCriterion("support_num >=", value, "supportNum");
            return (Criteria) this;
        }

        public Criteria andSupportNumLessThan(Long value) {
            addCriterion("support_num <", value, "supportNum");
            return (Criteria) this;
        }

        public Criteria andSupportNumLessThanOrEqualTo(Long value) {
            addCriterion("support_num <=", value, "supportNum");
            return (Criteria) this;
        }

        public Criteria andSupportNumIn(List<Long> values) {
            addCriterion("support_num in", values, "supportNum");
            return (Criteria) this;
        }

        public Criteria andSupportNumNotIn(List<Long> values) {
            addCriterion("support_num not in", values, "supportNum");
            return (Criteria) this;
        }

        public Criteria andSupportNumBetween(Long value1, Long value2) {
            addCriterion("support_num between", value1, value2, "supportNum");
            return (Criteria) this;
        }

        public Criteria andSupportNumNotBetween(Long value1, Long value2) {
            addCriterion("support_num not between", value1, value2, "supportNum");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIsNull() {
            addCriterion("create_time is null");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIsNotNull() {
            addCriterion("create_time is not null");
            return (Criteria) this;
        }

        public Criteria andCreateTimeEqualTo(Date value) {
            addCriterion("create_time =", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotEqualTo(Date value) {
            addCriterion("create_time <>", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeGreaterThan(Date value) {
            addCriterion("create_time >", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("create_time >=", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeLessThan(Date value) {
            addCriterion("create_time <", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeLessThanOrEqualTo(Date value) {
            addCriterion("create_time <=", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIn(List<Date> values) {
            addCriterion("create_time in", values, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotIn(List<Date> values) {
            addCriterion("create_time not in", values, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeBetween(Date value1, Date value2) {
            addCriterion("create_time between", value1, value2, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotBetween(Date value1, Date value2) {
            addCriterion("create_time not between", value1, value2, "createTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIsNull() {
            addCriterion("update_time is null");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIsNotNull() {
            addCriterion("update_time is not null");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeEqualTo(Date value) {
            addCriterion("update_time =", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotEqualTo(Date value) {
            addCriterion("update_time <>", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeGreaterThan(Date value) {
            addCriterion("update_time >", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("update_time >=", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeLessThan(Date value) {
            addCriterion("update_time <", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeLessThanOrEqualTo(Date value) {
            addCriterion("update_time <=", value, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeIn(List<Date> values) {
            addCriterion("update_time in", values, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotIn(List<Date> values) {
            addCriterion("update_time not in", values, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeBetween(Date value1, Date value2) {
            addCriterion("update_time between", value1, value2, "updateTime");
            return (Criteria) this;
        }

        public Criteria andUpdateTimeNotBetween(Date value1, Date value2) {
            addCriterion("update_time not between", value1, value2, "updateTime");
            return (Criteria) this;
        }

        public Criteria andIsReplyIsNull() {
            addCriterion("is_reply is null");
            return (Criteria) this;
        }

        public Criteria andIsReplyIsNotNull() {
            addCriterion("is_reply is not null");
            return (Criteria) this;
        }

        public Criteria andIsReplyEqualTo(Integer value) {
            addCriterion("is_reply =", value, "isReply");
            return (Criteria) this;
        }

        public Criteria andIsReplyNotEqualTo(Integer value) {
            addCriterion("is_reply <>", value, "isReply");
            return (Criteria) this;
        }

        public Criteria andIsReplyGreaterThan(Integer value) {
            addCriterion("is_reply >", value, "isReply");
            return (Criteria) this;
        }

        public Criteria andIsReplyGreaterThanOrEqualTo(Integer value) {
            addCriterion("is_reply >=", value, "isReply");
            return (Criteria) this;
        }

        public Criteria andIsReplyLessThan(Integer value) {
            addCriterion("is_reply <", value, "isReply");
            return (Criteria) this;
        }

        public Criteria andIsReplyLessThanOrEqualTo(Integer value) {
            addCriterion("is_reply <=", value, "isReply");
            return (Criteria) this;
        }

        public Criteria andIsReplyIn(List<Integer> values) {
            addCriterion("is_reply in", values, "isReply");
            return (Criteria) this;
        }

        public Criteria andIsReplyNotIn(List<Integer> values) {
            addCriterion("is_reply not in", values, "isReply");
            return (Criteria) this;
        }

        public Criteria andIsReplyBetween(Integer value1, Integer value2) {
            addCriterion("is_reply between", value1, value2, "isReply");
            return (Criteria) this;
        }

        public Criteria andIsReplyNotBetween(Integer value1, Integer value2) {
            addCriterion("is_reply not between", value1, value2, "isReply");
            return (Criteria) this;
        }

        public Criteria andReplyDiscussIdIsNull() {
            addCriterion("reply_discuss_id is null");
            return (Criteria) this;
        }

        public Criteria andReplyDiscussIdIsNotNull() {
            addCriterion("reply_discuss_id is not null");
            return (Criteria) this;
        }

        public Criteria andReplyDiscussIdEqualTo(Long value) {
            addCriterion("reply_discuss_id =", value, "replyDiscussId");
            return (Criteria) this;
        }

        public Criteria andReplyDiscussIdNotEqualTo(Long value) {
            addCriterion("reply_discuss_id <>", value, "replyDiscussId");
            return (Criteria) this;
        }

        public Criteria andReplyDiscussIdGreaterThan(Long value) {
            addCriterion("reply_discuss_id >", value, "replyDiscussId");
            return (Criteria) this;
        }

        public Criteria andReplyDiscussIdGreaterThanOrEqualTo(Long value) {
            addCriterion("reply_discuss_id >=", value, "replyDiscussId");
            return (Criteria) this;
        }

        public Criteria andReplyDiscussIdLessThan(Long value) {
            addCriterion("reply_discuss_id <", value, "replyDiscussId");
            return (Criteria) this;
        }

        public Criteria andReplyDiscussIdLessThanOrEqualTo(Long value) {
            addCriterion("reply_discuss_id <=", value, "replyDiscussId");
            return (Criteria) this;
        }

        public Criteria andReplyDiscussIdIn(List<Long> values) {
            addCriterion("reply_discuss_id in", values, "replyDiscussId");
            return (Criteria) this;
        }

        public Criteria andReplyDiscussIdNotIn(List<Long> values) {
            addCriterion("reply_discuss_id not in", values, "replyDiscussId");
            return (Criteria) this;
        }

        public Criteria andReplyDiscussIdBetween(Long value1, Long value2) {
            addCriterion("reply_discuss_id between", value1, value2, "replyDiscussId");
            return (Criteria) this;
        }

        public Criteria andReplyDiscussIdNotBetween(Long value1, Long value2) {
            addCriterion("reply_discuss_id not between", value1, value2, "replyDiscussId");
            return (Criteria) this;
        }

        public Criteria andIsDeleteIsNull() {
            addCriterion("is_delete is null");
            return (Criteria) this;
        }

        public Criteria andIsDeleteIsNotNull() {
            addCriterion("is_delete is not null");
            return (Criteria) this;
        }

        public Criteria andIsDeleteEqualTo(Integer value) {
            addCriterion("is_delete =", value, "isDelete");
            return (Criteria) this;
        }

        public Criteria andIsDeleteNotEqualTo(Integer value) {
            addCriterion("is_delete <>", value, "isDelete");
            return (Criteria) this;
        }

        public Criteria andIsDeleteGreaterThan(Integer value) {
            addCriterion("is_delete >", value, "isDelete");
            return (Criteria) this;
        }

        public Criteria andIsDeleteGreaterThanOrEqualTo(Integer value) {
            addCriterion("is_delete >=", value, "isDelete");
            return (Criteria) this;
        }

        public Criteria andIsDeleteLessThan(Integer value) {
            addCriterion("is_delete <", value, "isDelete");
            return (Criteria) this;
        }

        public Criteria andIsDeleteLessThanOrEqualTo(Integer value) {
            addCriterion("is_delete <=", value, "isDelete");
            return (Criteria) this;
        }

        public Criteria andIsDeleteIn(List<Integer> values) {
            addCriterion("is_delete in", values, "isDelete");
            return (Criteria) this;
        }

        public Criteria andIsDeleteNotIn(List<Integer> values) {
            addCriterion("is_delete not in", values, "isDelete");
            return (Criteria) this;
        }

        public Criteria andIsDeleteBetween(Integer value1, Integer value2) {
            addCriterion("is_delete between", value1, value2, "isDelete");
            return (Criteria) this;
        }

        public Criteria andIsDeleteNotBetween(Integer value1, Integer value2) {
            addCriterion("is_delete not between", value1, value2, "isDelete");
            return (Criteria) this;
        }

        public Criteria andUserIdIsNull() {
            addCriterion("user_id is null");
            return (Criteria) this;
        }

        public Criteria andUserIdIsNotNull() {
            addCriterion("user_id is not null");
            return (Criteria) this;
        }

        public Criteria andUserIdEqualTo(Long value) {
            addCriterion("user_id =", value, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdNotEqualTo(Long value) {
            addCriterion("user_id <>", value, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdGreaterThan(Long value) {
            addCriterion("user_id >", value, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdGreaterThanOrEqualTo(Long value) {
            addCriterion("user_id >=", value, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdLessThan(Long value) {
            addCriterion("user_id <", value, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdLessThanOrEqualTo(Long value) {
            addCriterion("user_id <=", value, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdIn(List<Long> values) {
            addCriterion("user_id in", values, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdNotIn(List<Long> values) {
            addCriterion("user_id not in", values, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdBetween(Long value1, Long value2) {
            addCriterion("user_id between", value1, value2, "userId");
            return (Criteria) this;
        }

        public Criteria andUserIdNotBetween(Long value1, Long value2) {
            addCriterion("user_id not between", value1, value2, "userId");
            return (Criteria) this;
        }

        public Criteria andBeReportIsNull() {
            addCriterion("be_report is null");
            return (Criteria) this;
        }

        public Criteria andBeReportIsNotNull() {
            addCriterion("be_report is not null");
            return (Criteria) this;
        }

        public Criteria andBeReportEqualTo(Integer value) {
            addCriterion("be_report =", value, "beReport");
            return (Criteria) this;
        }

        public Criteria andBeReportNotEqualTo(Integer value) {
            addCriterion("be_report <>", value, "beReport");
            return (Criteria) this;
        }

        public Criteria andBeReportGreaterThan(Integer value) {
            addCriterion("be_report >", value, "beReport");
            return (Criteria) this;
        }

        public Criteria andBeReportGreaterThanOrEqualTo(Integer value) {
            addCriterion("be_report >=", value, "beReport");
            return (Criteria) this;
        }

        public Criteria andBeReportLessThan(Integer value) {
            addCriterion("be_report <", value, "beReport");
            return (Criteria) this;
        }

        public Criteria andBeReportLessThanOrEqualTo(Integer value) {
            addCriterion("be_report <=", value, "beReport");
            return (Criteria) this;
        }

        public Criteria andBeReportIn(List<Integer> values) {
            addCriterion("be_report in", values, "beReport");
            return (Criteria) this;
        }

        public Criteria andBeReportNotIn(List<Integer> values) {
            addCriterion("be_report not in", values, "beReport");
            return (Criteria) this;
        }

        public Criteria andBeReportBetween(Integer value1, Integer value2) {
            addCriterion("be_report between", value1, value2, "beReport");
            return (Criteria) this;
        }

        public Criteria andBeReportNotBetween(Integer value1, Integer value2) {
            addCriterion("be_report not between", value1, value2, "beReport");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {
        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}