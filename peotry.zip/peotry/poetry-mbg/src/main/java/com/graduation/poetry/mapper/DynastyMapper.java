package com.graduation.poetry.mapper;

import com.graduation.poetry.model.Dynasty;
import com.graduation.poetry.model.DynastyExample;
import java.util.List;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface DynastyMapper {
    long countByExample(DynastyExample example);

    int deleteByExample(DynastyExample example);

    int deleteByPrimaryKey(Long id);

    int insert(Dynasty record);

    int insertSelective(Dynasty record);

    List<Dynasty> selectByExample(DynastyExample example);

    Dynasty selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") Dynasty record, @Param("example") DynastyExample example);

    int updateByExample(@Param("record") Dynasty record, @Param("example") DynastyExample example);

    int updateByPrimaryKeySelective(Dynasty record);

    int updateByPrimaryKey(Dynasty record);
}