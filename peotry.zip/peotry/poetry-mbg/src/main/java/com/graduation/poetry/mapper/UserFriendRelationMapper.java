package com.graduation.poetry.mapper;

import com.graduation.poetry.model.UserFriendRelation;
import com.graduation.poetry.model.UserFriendRelationExample;
import java.util.List;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface UserFriendRelationMapper {
    long countByExample(UserFriendRelationExample example);

    int deleteByExample(UserFriendRelationExample example);

    int deleteByPrimaryKey(Long id);

    int insert(UserFriendRelation record);

    int insertSelective(UserFriendRelation record);

    List<UserFriendRelation> selectByExample(UserFriendRelationExample example);

    UserFriendRelation selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") UserFriendRelation record, @Param("example") UserFriendRelationExample example);

    int updateByExample(@Param("record") UserFriendRelation record, @Param("example") UserFriendRelationExample example);

    int updateByPrimaryKeySelective(UserFriendRelation record);

    int updateByPrimaryKey(UserFriendRelation record);
}