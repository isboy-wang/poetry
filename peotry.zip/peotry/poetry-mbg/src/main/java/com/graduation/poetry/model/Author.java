package com.graduation.poetry.model;

import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;
import java.util.Date;

public class Author implements Serializable {
    @ApiModelProperty(value = "唯一标识")
    private Long id;

    @ApiModelProperty(value = "作者名字")
    private String authorName;

    @ApiModelProperty(value = "作者背景")
    private String authorBackground;

    @ApiModelProperty(value = "作者朝代")
    private String authorDynasty;

    @ApiModelProperty(value = "作者诗词数量")
    private String poetryNumber;

    @ApiModelProperty(value = "创建时间")
    private Date createTime;

    @ApiModelProperty(value = "修改时间")
    private Date updateTime;

    @ApiModelProperty(value = "作者画像")
    private String authorImg;

    @ApiModelProperty(value = "作者所有诗词链接")
    private String poetryUrl;

    private static final long serialVersionUID = 1L;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getAuthorName() {
        return authorName;
    }

    public void setAuthorName(String authorName) {
        this.authorName = authorName;
    }

    public String getAuthorBackground() {
        return authorBackground;
    }

    public void setAuthorBackground(String authorBackground) {
        this.authorBackground = authorBackground;
    }

    public String getAuthorDynasty() {
        return authorDynasty;
    }

    public void setAuthorDynasty(String authorDynasty) {
        this.authorDynasty = authorDynasty;
    }

    public String getPoetryNumber() {
        return poetryNumber;
    }

    public void setPoetryNumber(String poetryNumber) {
        this.poetryNumber = poetryNumber;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public String getAuthorImg() {
        return authorImg;
    }

    public void setAuthorImg(String authorImg) {
        this.authorImg = authorImg;
    }

    public String getPoetryUrl() {
        return poetryUrl;
    }

    public void setPoetryUrl(String poetryUrl) {
        this.poetryUrl = poetryUrl;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", id=").append(id);
        sb.append(", authorName=").append(authorName);
        sb.append(", authorBackground=").append(authorBackground);
        sb.append(", authorDynasty=").append(authorDynasty);
        sb.append(", poetryNumber=").append(poetryNumber);
        sb.append(", createTime=").append(createTime);
        sb.append(", updateTime=").append(updateTime);
        sb.append(", authorImg=").append(authorImg);
        sb.append(", poetryUrl=").append(poetryUrl);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }
}