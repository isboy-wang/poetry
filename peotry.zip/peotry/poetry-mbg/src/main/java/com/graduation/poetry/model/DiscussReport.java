package com.graduation.poetry.model;

import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;
import java.util.Date;

public class DiscussReport implements Serializable {
    private Long id;

    @ApiModelProperty(value = "评论id")
    private Long beReportDiscussId;

    @ApiModelProperty(value = "评论内容")
    private String discussContent;

    @ApiModelProperty(value = "评论用户的id")
    private Long userOfDiscussId;

    @ApiModelProperty(value = "举报用户id")
    private Long reportUserId;

    @ApiModelProperty(value = "是否处理（1为是，2为否）")
    private Integer isDispose;

    @ApiModelProperty(value = "创建时间")
    private Date createTime;

    @ApiModelProperty(value = "修改时间")
    private Date updateTime;

    private static final long serialVersionUID = 1L;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getBeReportDiscussId() {
        return beReportDiscussId;
    }

    public void setBeReportDiscussId(Long beReportDiscussId) {
        this.beReportDiscussId = beReportDiscussId;
    }

    public String getDiscussContent() {
        return discussContent;
    }

    public void setDiscussContent(String discussContent) {
        this.discussContent = discussContent;
    }

    public Long getUserOfDiscussId() {
        return userOfDiscussId;
    }

    public void setUserOfDiscussId(Long userOfDiscussId) {
        this.userOfDiscussId = userOfDiscussId;
    }

    public Long getReportUserId() {
        return reportUserId;
    }

    public void setReportUserId(Long reportUserId) {
        this.reportUserId = reportUserId;
    }

    public Integer getIsDispose() {
        return isDispose;
    }

    public void setIsDispose(Integer isDispose) {
        this.isDispose = isDispose;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", id=").append(id);
        sb.append(", beReportDiscussId=").append(beReportDiscussId);
        sb.append(", discussContent=").append(discussContent);
        sb.append(", userOfDiscussId=").append(userOfDiscussId);
        sb.append(", reportUserId=").append(reportUserId);
        sb.append(", isDispose=").append(isDispose);
        sb.append(", createTime=").append(createTime);
        sb.append(", updateTime=").append(updateTime);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }
}