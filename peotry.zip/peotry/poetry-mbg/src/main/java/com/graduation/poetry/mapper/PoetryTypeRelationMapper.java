package com.graduation.poetry.mapper;

import com.graduation.poetry.model.PoetryTypeRelation;
import com.graduation.poetry.model.PoetryTypeRelationExample;
import java.util.List;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface PoetryTypeRelationMapper {
    long countByExample(PoetryTypeRelationExample example);

    int deleteByExample(PoetryTypeRelationExample example);

    int deleteByPrimaryKey(Long id);

    int insert(PoetryTypeRelation record);

    int insertSelective(PoetryTypeRelation record);

    List<PoetryTypeRelation> selectByExample(PoetryTypeRelationExample example);

    PoetryTypeRelation selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") PoetryTypeRelation record, @Param("example") PoetryTypeRelationExample example);

    int updateByExample(@Param("record") PoetryTypeRelation record, @Param("example") PoetryTypeRelationExample example);

    int updateByPrimaryKeySelective(PoetryTypeRelation record);

    int updateByPrimaryKey(PoetryTypeRelation record);
}