package com.graduation.poetry.mapper;

import com.graduation.poetry.model.PoetryDiscuss;
import com.graduation.poetry.model.PoetryDiscussExample;
import java.util.List;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface PoetryDiscussMapper {
    long countByExample(PoetryDiscussExample example);

    int deleteByExample(PoetryDiscussExample example);

    int deleteByPrimaryKey(Long id);

    int insert(PoetryDiscuss record);

    int insertSelective(PoetryDiscuss record);

    List<PoetryDiscuss> selectByExample(PoetryDiscussExample example);

    PoetryDiscuss selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") PoetryDiscuss record, @Param("example") PoetryDiscussExample example);

    int updateByExample(@Param("record") PoetryDiscuss record, @Param("example") PoetryDiscussExample example);

    int updateByPrimaryKeySelective(PoetryDiscuss record);

    int updateByPrimaryKey(PoetryDiscuss record);
}