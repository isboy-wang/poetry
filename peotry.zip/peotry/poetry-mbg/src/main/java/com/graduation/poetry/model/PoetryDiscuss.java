package com.graduation.poetry.model;

import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;
import java.util.Date;

public class PoetryDiscuss implements Serializable {
    private Long id;

    @ApiModelProperty(value = "诗词评论")
    private String poetryDiscuss;

    @ApiModelProperty(value = "诗词id")
    private Long poetryId;

    @ApiModelProperty(value = "评论点赞数")
    private Long supportNum;

    @ApiModelProperty(value = "创建时间")
    private Date createTime;

    @ApiModelProperty(value = "修改时间")
    private Date updateTime;

    @ApiModelProperty(value = "是否是回复（1表示是回复，2表示不是回复）")
    private Integer isReply;

    @ApiModelProperty(value = "回复的评论的id")
    private Long replyDiscussId;

    @ApiModelProperty(value = "是否删除（1表示是，2表示否）")
    private Integer isDelete;

    @ApiModelProperty(value = "发表评论用户id")
    private Long userId;

    @ApiModelProperty(value = "是否被举报（1表示是，2表示否）")
    private Integer beReport;

    private static final long serialVersionUID = 1L;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getPoetryDiscuss() {
        return poetryDiscuss;
    }

    public void setPoetryDiscuss(String poetryDiscuss) {
        this.poetryDiscuss = poetryDiscuss;
    }

    public Long getPoetryId() {
        return poetryId;
    }

    public void setPoetryId(Long poetryId) {
        this.poetryId = poetryId;
    }

    public Long getSupportNum() {
        return supportNum;
    }

    public void setSupportNum(Long supportNum) {
        this.supportNum = supportNum;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Integer getIsReply() {
        return isReply;
    }

    public void setIsReply(Integer isReply) {
        this.isReply = isReply;
    }

    public Long getReplyDiscussId() {
        return replyDiscussId;
    }

    public void setReplyDiscussId(Long replyDiscussId) {
        this.replyDiscussId = replyDiscussId;
    }

    public Integer getIsDelete() {
        return isDelete;
    }

    public void setIsDelete(Integer isDelete) {
        this.isDelete = isDelete;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public Integer getBeReport() {
        return beReport;
    }

    public void setBeReport(Integer beReport) {
        this.beReport = beReport;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", id=").append(id);
        sb.append(", poetryDiscuss=").append(poetryDiscuss);
        sb.append(", poetryId=").append(poetryId);
        sb.append(", supportNum=").append(supportNum);
        sb.append(", createTime=").append(createTime);
        sb.append(", updateTime=").append(updateTime);
        sb.append(", isReply=").append(isReply);
        sb.append(", replyDiscussId=").append(replyDiscussId);
        sb.append(", isDelete=").append(isDelete);
        sb.append(", userId=").append(userId);
        sb.append(", beReport=").append(beReport);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }
}