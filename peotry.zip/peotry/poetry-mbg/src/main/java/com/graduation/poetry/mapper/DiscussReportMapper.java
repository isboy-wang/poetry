package com.graduation.poetry.mapper;

import com.graduation.poetry.model.DiscussReport;
import com.graduation.poetry.model.DiscussReportExample;
import java.util.List;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface DiscussReportMapper {
    long countByExample(DiscussReportExample example);

    int deleteByExample(DiscussReportExample example);

    int deleteByPrimaryKey(Long id);

    int insert(DiscussReport record);

    int insertSelective(DiscussReport record);

    List<DiscussReport> selectByExample(DiscussReportExample example);

    DiscussReport selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") DiscussReport record, @Param("example") DiscussReportExample example);

    int updateByExample(@Param("record") DiscussReport record, @Param("example") DiscussReportExample example);

    int updateByPrimaryKeySelective(DiscussReport record);

    int updateByPrimaryKey(DiscussReport record);
}