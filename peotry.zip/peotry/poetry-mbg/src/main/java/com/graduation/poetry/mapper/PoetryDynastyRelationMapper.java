package com.graduation.poetry.mapper;

import com.graduation.poetry.model.PoetryDynastyRelation;
import com.graduation.poetry.model.PoetryDynastyRelationExample;
import java.util.List;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface PoetryDynastyRelationMapper {
    long countByExample(PoetryDynastyRelationExample example);

    int deleteByExample(PoetryDynastyRelationExample example);

    int deleteByPrimaryKey(Long id);

    int insert(PoetryDynastyRelation record);

    int insertSelective(PoetryDynastyRelation record);

    List<PoetryDynastyRelation> selectByExample(PoetryDynastyRelationExample example);

    PoetryDynastyRelation selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") PoetryDynastyRelation record, @Param("example") PoetryDynastyRelationExample example);

    int updateByExample(@Param("record") PoetryDynastyRelation record, @Param("example") PoetryDynastyRelationExample example);

    int updateByPrimaryKeySelective(PoetryDynastyRelation record);

    int updateByPrimaryKey(PoetryDynastyRelation record);
}