package com.graduation.poetry.model;

import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;
import java.util.Date;

public class UserLike implements Serializable {
    @ApiModelProperty(value = " ")
    private Long id;

    @ApiModelProperty(value = "用户id")
    private Long userId;

    @ApiModelProperty(value = "诗词作者id")
    private Long poetryAuthorId;

    @ApiModelProperty(value = "创建时间")
    private Date createTime;

    @ApiModelProperty(value = "修改时间")
    private Date updateTime;

    @ApiModelProperty(value = "是否为作者本人填写（1为是，2为否）")
    private Integer isUserWrite;

    @ApiModelProperty(value = "喜好诗词朝代")
    private Long poetryDynastyId;

    @ApiModelProperty(value = "打开该作者诗词次数")
    private Long openAuthorNumber;

    @ApiModelProperty(value = "打开该朝代诗词次数")
    private Long openDynastyNumber;

    private static final long serialVersionUID = 1L;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public Long getPoetryAuthorId() {
        return poetryAuthorId;
    }

    public void setPoetryAuthorId(Long poetryAuthorId) {
        this.poetryAuthorId = poetryAuthorId;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Integer getIsUserWrite() {
        return isUserWrite;
    }

    public void setIsUserWrite(Integer isUserWrite) {
        this.isUserWrite = isUserWrite;
    }

    public Long getPoetryDynastyId() {
        return poetryDynastyId;
    }

    public void setPoetryDynastyId(Long poetryDynastyId) {
        this.poetryDynastyId = poetryDynastyId;
    }

    public Long getOpenAuthorNumber() {
        return openAuthorNumber;
    }

    public void setOpenAuthorNumber(Long openAuthorNumber) {
        this.openAuthorNumber = openAuthorNumber;
    }

    public Long getOpenDynastyNumber() {
        return openDynastyNumber;
    }

    public void setOpenDynastyNumber(Long openDynastyNumber) {
        this.openDynastyNumber = openDynastyNumber;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", id=").append(id);
        sb.append(", userId=").append(userId);
        sb.append(", poetryAuthorId=").append(poetryAuthorId);
        sb.append(", createTime=").append(createTime);
        sb.append(", updateTime=").append(updateTime);
        sb.append(", isUserWrite=").append(isUserWrite);
        sb.append(", poetryDynastyId=").append(poetryDynastyId);
        sb.append(", openAuthorNumber=").append(openAuthorNumber);
        sb.append(", openDynastyNumber=").append(openDynastyNumber);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }
}