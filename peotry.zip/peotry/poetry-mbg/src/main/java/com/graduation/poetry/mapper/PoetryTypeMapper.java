package com.graduation.poetry.mapper;

import com.graduation.poetry.model.PoetryType;
import com.graduation.poetry.model.PoetryTypeExample;
import java.util.List;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface PoetryTypeMapper {
    long countByExample(PoetryTypeExample example);

    int deleteByExample(PoetryTypeExample example);

    int deleteByPrimaryKey(Long id);

    int insert(PoetryType record);

    int insertSelective(PoetryType record);

    List<PoetryType> selectByExample(PoetryTypeExample example);

    PoetryType selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") PoetryType record, @Param("example") PoetryTypeExample example);

    int updateByExample(@Param("record") PoetryType record, @Param("example") PoetryTypeExample example);

    int updateByPrimaryKeySelective(PoetryType record);

    int updateByPrimaryKey(PoetryType record);
}