package com.graduation.poetry.portal.util;

import com.graduation.poetry.mapper.UserLikeMapper;
import com.graduation.poetry.model.UserLikeExample;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Random;

public class Try {
    public static void main(String[] args) {



    }
}
