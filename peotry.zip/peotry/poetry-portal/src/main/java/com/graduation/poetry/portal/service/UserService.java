package com.graduation.poetry.portal.service;

import com.github.pagehelper.PageInfo;
import com.graduation.poetry.enums.CollectResult;
import com.graduation.poetry.enums.RecordBrowsingResult;
import com.graduation.poetry.enums.RegisterResult;
import com.graduation.poetry.model.PoetryContent;
import com.graduation.poetry.model.User;
import com.graduation.poetry.model.UserCollect;
import com.graduation.poetry.portal.model.dto.UserMessageParam;
import com.graduation.poetry.portal.model.dto.UserRegisterParam;
import com.graduation.poetry.portal.model.vo.CollectVo;
import com.graduation.poetry.portal.model.vo.RecommendListVo;

import java.util.List;
import java.util.Map;

public interface UserService {
    /**
     *根据用户名返回用户
     * @param userName
     * @return
     */
    User getUserByUsername(String userName);


    /**
     *   根据注册类注册
     * @param userRegisterParam
     * @return 返回结果枚举
     */
    RegisterResult register(UserRegisterParam userRegisterParam);

    /**
     * 根据用户名密码登录
     * @param userName
     * @param password
     * @return 返回键值对数组（Map）
     */
    Map<String,String> login(String userName,String password);

    /**
     * 将用户打开的诗词存入数据库
     * @param authorId
     * @param dynastyId
     * @return 存储成功返回1，失败返回0
     */
    int recordLike(Long authorId,Long dynastyId);


    /**
     * 根据用户喜好返回
     * @return 返回推荐诗词列表
     */
    List<RecommendListVo> recommend();


    /**
     * 记录用户浏览记录
     * @param poetryId 诗词id
     * @return 成功返回1，失败返回0
     */
    RecordBrowsingResult recordBrowsing(Long poetryId);


    /**
     * 用户收藏(调用第一次收藏，第二次取消收藏）
     * @param poetryId 诗词id
     * @return 成功返回1，失败返回0
     */
    CollectResult collectPoetry(Long poetryId);


    /**
     * 更新用户信息
     * @param userMessageParam 用户信息对象
     * @return 成功返回1，失败返回0
     */
     int updateUserMessage(UserMessageParam userMessageParam);


    /**
     * 返回诗词列表

     * @return 返回诗词列表
     */
    List<CollectVo> getCollectList();



}
