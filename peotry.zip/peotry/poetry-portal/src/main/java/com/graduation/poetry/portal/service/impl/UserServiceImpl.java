package com.graduation.poetry.portal.service.impl;

import com.graduation.poetry.enums.CollectResult;
import com.graduation.poetry.enums.RecordBrowsingResult;
import com.graduation.poetry.enums.RegisterResult;
import com.graduation.poetry.mapper.*;
import com.graduation.poetry.model.*;
import com.graduation.poetry.portal.model.dto.UserMessageParam;
import com.graduation.poetry.portal.model.dto.UserRegisterParam;
import com.graduation.poetry.portal.model.vo.CollectVo;
import com.graduation.poetry.portal.model.vo.RecommendListVo;
import com.graduation.poetry.portal.service.UserService;
import com.graduation.poetry.portal.util.SecurityUtils;
import com.graduation.poetry.security.util.JwtTokenUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.*;

@Service
public class UserServiceImpl implements UserService {
    public static final Logger logger = LoggerFactory.getLogger(UserServiceImpl.class);

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private UserMapper userMapper;

    @Autowired
    private JwtTokenUtil jwtTokenUtil;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private UserLikeMapper userLikeMapper;

    @Autowired
    private PoetryContentMapper poetryContentMapper;

    @Autowired
    private AuthorMapper authorMapper;

    @Autowired
    private DynastyMapper dynastyMapper;

    @Autowired
    private BrowsingHistoryMapper browsingHistoryMapper;

    @Autowired
    private UserCollectMapper userCollectMapper;

    @Override
    public User getUserByUsername(String userName) {

        UserExample example = new UserExample();
        example.createCriteria().andUserNameEqualTo(userName);
        List<User> users = userMapper.selectByExample(example);

//        if(users != null && users.size()>0){}
        if(!CollectionUtils.isEmpty(users)){
            return users.get(0);
        }

        return null;
    }


    //注册
    @Override
    public RegisterResult register(UserRegisterParam userRegisterParam) {
        UserExample example = new UserExample();
        example.createCriteria().andUserNameEqualTo(userRegisterParam.getUserName());
        //如果账号密码为空
        if(userRegisterParam.getUserName() == null || userRegisterParam.getPassword() == null){
            return RegisterResult.NAME_PASSWORD_NULL;
        }
        //如果用户名存在
        if(userMapper.countByExample(example) > 0){
            return RegisterResult.USERNAME_EXIST;
        }
        //如果账号密码过长(账号密码长度都不大于10)

        if(userRegisterParam.getUserName().length() >= 10 || userRegisterParam.getPassword().length()>10){
            return RegisterResult.NAME_PASSWORD_TOO_LONG;
        }
        User user = new User();
        user.setUserName(userRegisterParam.getUserName());
        user.setPassword(passwordEncoder.encode(userRegisterParam.getPassword()));
        user.setPhone(userRegisterParam.getPhone());
        user.setIsManager(1);
        user.setIsBannedLogin(2);
        user.setBeReport(2);
//        user.setBirthday(userRegisterParam.getBirthday());
        if(userMapper.insertSelective(user) > 0){
            return RegisterResult.REG_SUCCESS;
        }
        return RegisterResult.REG_FAILED;
    }
//登录
    @Override
    public Map<String, String> login(String userName, String password) {
        UsernamePasswordAuthenticationToken token = new UsernamePasswordAuthenticationToken(userName, password);
        Authentication authentication = null;


        UserExample example = new UserExample();
        example.createCriteria().andUserNameEqualTo(userName);
        List<User> users = userMapper.selectByExample(example);

        if(users.size()>0 && users.get(0).getIsBannedLogin()==1){
            Map<String,String> map = new HashMap<>();
            return map;
        }
        //验证token
        try{
            authentication = authenticationManager.authenticate(token);
        }catch (AuthenticationException e){
            logger.error("用户名或密码错误"+e);
        }

//        SecurityContextHolder.getContext().setAuthentication(authenticate);
        SecurityContextHolder.getContext().setAuthentication(authentication);

        Map<String,String> tokenMap = new HashMap<>();
        if(authentication != null)
        {
            //通过验证返回的authenticate中获取userDetails
            UserDetails userDetails =(UserDetails) authentication.getPrincipal();
            //根据userDetailis生成token字符串
            String tokenString = jwtTokenUtil.generateToken(userDetails);
            tokenMap.put("token",tokenString);
            tokenMap.put("tokenHead",jwtTokenUtil.getTokenHead());
            tokenMap.put("tokenHeader",jwtTokenUtil.getTokenHeader());

        }


        return tokenMap;
    }

    //插入作者喜爱诗词偏好
    @Override
    public int recordLike(Long authorId, Long dynastyId) {
        //获取当前用户id
        User currentUser = SecurityUtils.getCurrentUser();
        long userId = currentUser.getId();
        UserLikeExample userLikeAuthorExample = new UserLikeExample();
        userLikeAuthorExample.createCriteria().andUserIdEqualTo(userId).andPoetryAuthorIdEqualTo(authorId);
        UserLikeExample userLikeDynastyExample = new UserLikeExample();
        userLikeDynastyExample.createCriteria().andUserIdEqualTo(userId).andPoetryDynastyIdEqualTo(dynastyId);


        if(userLikeMapper.countByExample(userLikeAuthorExample) <= 0){//查看有没有作者的记录
            System.out.println("作者插入");
            UserLike userLike = new UserLike();
            userLike.setUserId(userId);
            userLike.setPoetryAuthorId(authorId);
            userLike.setOpenAuthorNumber((long)1);
            userLike.setIsUserWrite(2);
            if (userLikeMapper.insertSelective(userLike) <= 0){   //没有的话添加一个
                return 0;

            }

        }else{
            System.out.println("作者次数增加");
            UserLike userLike = userLikeMapper.selectByExample(userLikeAuthorExample).get(0);
            Long openAuthorNumber = userLike.getOpenAuthorNumber();
            UserLike updateUserLike = new UserLike();
            updateUserLike.setOpenAuthorNumber(openAuthorNumber+1);//有该作者的记录，就将查看次数加1
            if (userLikeMapper.updateByExampleSelective(updateUserLike,userLikeAuthorExample) <= 0){
                return 0;
            }
        }
        if(userLikeMapper.countByExample(userLikeDynastyExample) <= 0){//查看有没有朝代的记录
            UserLike userLike = new UserLike();
            userLike.setUserId(userId);
            userLike.setPoetryDynastyId(dynastyId);
            userLike.setOpenDynastyNumber((long)1);
            userLike.setIsUserWrite(2);
            if(userLikeMapper.insertSelective(userLike) <= 0){
                return 0;
            }//没有的话添加一个

        }else{
            UserLike userLike = userLikeMapper.selectByExample(userLikeDynastyExample).get(0);
            Long openDynastyNumber = userLike.getOpenDynastyNumber();
            UserLike updateUserLike = new UserLike();
            updateUserLike.setOpenDynastyNumber(openDynastyNumber+1);//有该朝代的记录，就将查看次数加1
            if(userLikeMapper.updateByExampleSelective(updateUserLike,userLikeDynastyExample) <= 0){
                return 0;
            }
        }
        return 1;
    }

    //推荐算法，根据用户喜好推荐

    @Override
    public List<RecommendListVo> recommend() {

        List<RecommendListVo> recommendListVos = new ArrayList<>();



        User currentUser = SecurityUtils.getCurrentUser();//看看当前用户是否登录

        if(currentUser == null)//没有登录
        {
            Random random = new Random();//默认构造方法

            for(int i= 0;i<10;i++){
                long randomId = random.nextInt(3000);
//                PoetryContentExample poetryContentExample = new PoetryContentExample();
//                poetryContentExample.createCriteria().andIdEqualTo(randomId);
//                PageHelper.startPage(pageNum,pageSize);//分页插件，分页插件只对下一个sql起作用
                PoetryContent poetryContent = poetryContentMapper.selectByPrimaryKey(randomId);
                RecommendListVo recommendVo = new RecommendListVo();
                recommendVo.setPoetryId(poetryContent.getId());
                recommendVo.setAuthor(poetryContent.getAuthor());
                recommendVo.setPoetryAnnotation(poetryContent.getPoetryAnnotation());//诗词注释
                recommendVo.setPoetryBackground(poetryContent.getPoetryBackground());
                recommendVo.setPoetryContent(poetryContent.getPoetryContent());
                recommendVo.setPoetryTranslate(poetryContent.getPoetryTranslate());//诗词翻译
                recommendVo.setPoetryName(poetryContent.getPoetryName());
                Author author = authorMapper.selectByPrimaryKey(poetryContent.getAuthorId());
                recommendVo.setDynasty(author.getAuthorDynasty());

                recommendListVos.add(recommendVo);//将返回的诗词放入列表中
            }
            //随机返回
            return recommendListVos;
        }

        //有登录，就获取他的喜好

        Long userId = currentUser.getId();
        UserLikeExample userLikeExample = new UserLikeExample();
        userLikeExample.createCriteria().andUserIdEqualTo(userId);
        List<UserLike> userLikes = userLikeMapper.selectByExample(userLikeExample);

        long writeAuthorId = 0;//用户自己填的喜好作者的id
        long writeDynastyId = 0;
        long firstAuthorNumber = 0;
        long firstAuthorId = 0;
        long secondAuthorNumber = 0;
        long secondAuthorId = 0;
        long firstDynastyNumber = 0;
        long firstDynastyId = 0;
        //获取作者爱好

        Random random = new Random();//默认构造方法
        for(UserLike like:userLikes){


            if(like.getIsUserWrite() == 1){//看看是不是用户自己填写的喜好
                writeAuthorId = like.getPoetryAuthorId();//获取作者自己写的喜爱作者id
                writeDynastyId = like.getPoetryDynastyId();//获取用户自己写的喜爱朝代id
            }else{

                if(like.getOpenAuthorNumber() == null){

                }else{
                    if(like.getOpenAuthorNumber()>firstAuthorNumber){
                        secondAuthorNumber = firstAuthorNumber;
                        secondAuthorId = firstAuthorId;
                        firstAuthorNumber = like.getOpenAuthorNumber();
                        firstAuthorId = like.getPoetryAuthorId();

                    }
                    if(like.getOpenAuthorNumber()<firstAuthorNumber && like.getOpenAuthorNumber()>secondAuthorNumber){
                        secondAuthorNumber = like.getOpenAuthorNumber();
                        secondAuthorId = like.getPoetryAuthorId();
                    }
                }



                if (like.getOpenDynastyNumber() == null) {

                }
                else if(like.getOpenDynastyNumber()>firstDynastyNumber){
                    firstDynastyNumber = like.getOpenDynastyNumber();
                    firstDynastyId = like.getPoetryDynastyId();

                }



            }
        }

        //根据用户爱好，返回诗词列表
        //根据喜好作者返回
        if(secondAuthorId != 0){
          //找两个第一作者，一个第二作者
            PoetryContentExample poetryContentExample = new PoetryContentExample();
            poetryContentExample.createCriteria().andAuthorIdEqualTo(firstAuthorId);
            List<PoetryContent> firstAuthorLikeList = poetryContentMapper.selectByExample(poetryContentExample);
            if(firstAuthorLikeList.size() >= 2){
                for(int i = 0;i<2;i++){
                    PoetryContent poetryContent = firstAuthorLikeList.get(random.nextInt(firstAuthorLikeList.size()));
                    RecommendListVo recommendVo = new RecommendListVo();
                    recommendVo.setPoetryId(poetryContent.getId());
                    recommendVo.setAuthor(poetryContent.getAuthor());
                    recommendVo.setPoetryAnnotation(poetryContent.getPoetryAnnotation());//诗词注释
                    recommendVo.setPoetryBackground(poetryContent.getPoetryBackground());
                    recommendVo.setPoetryContent(poetryContent.getPoetryContent());
                    recommendVo.setPoetryTranslate(poetryContent.getPoetryTranslate());//诗词翻译
                    recommendVo.setPoetryName(poetryContent.getPoetryName());
                    Author author = authorMapper.selectByPrimaryKey(poetryContent.getAuthorId());
                    recommendVo.setDynasty(author.getAuthorDynasty());

                    recommendListVos.add(recommendVo);//将返回的诗词放入列表中
                }
            }else {
                for (int i = 0; i < 2; i++)
                {
                    long randomId = random.nextInt(3000);
                    PoetryContent poetryContent = poetryContentMapper.selectByPrimaryKey(randomId);
                    RecommendListVo recommendVo = new RecommendListVo();
                    recommendVo.setAuthor(poetryContent.getAuthor());
                    recommendVo.setPoetryId(poetryContent.getId());
                    recommendVo.setPoetryAnnotation(poetryContent.getPoetryAnnotation());//诗词注释
                    recommendVo.setPoetryBackground(poetryContent.getPoetryBackground());
                    recommendVo.setPoetryContent(poetryContent.getPoetryContent());
                    recommendVo.setPoetryTranslate(poetryContent.getPoetryTranslate());//诗词翻译
                    recommendVo.setPoetryName(poetryContent.getPoetryName());
                    Author author = authorMapper.selectByPrimaryKey(poetryContent.getAuthorId());
                    recommendVo.setDynasty(author.getAuthorDynasty());

                    recommendListVos.add(recommendVo);//将返回的诗词放入列表中
                }
            }

            PoetryContentExample poetryContentExample1 = new PoetryContentExample();
            poetryContentExample.createCriteria().andAuthorIdEqualTo(secondAuthorId);
            List<PoetryContent> secondAuthorLikeList = poetryContentMapper.selectByExample(poetryContentExample1);
            if(secondAuthorLikeList.size() >= 1){

                    PoetryContent poetryContent = secondAuthorLikeList.get(random.nextInt(secondAuthorLikeList.size()));
                    RecommendListVo recommendVo = new RecommendListVo();
                    recommendVo.setAuthor(poetryContent.getAuthor());
                    recommendVo.setPoetryId(poetryContent.getId());
                    recommendVo.setPoetryAnnotation(poetryContent.getPoetryAnnotation());//诗词注释
                    recommendVo.setPoetryBackground(poetryContent.getPoetryBackground());
                    recommendVo.setPoetryContent(poetryContent.getPoetryContent());
                    recommendVo.setPoetryTranslate(poetryContent.getPoetryTranslate());//诗词翻译
                    recommendVo.setPoetryName(poetryContent.getPoetryName());
                    Author author = authorMapper.selectByPrimaryKey(poetryContent.getAuthorId());
                    recommendVo.setDynasty(author.getAuthorDynasty());

                    recommendListVos.add(recommendVo);//将返回的诗词放入列表中

            }else {

                    long randomId = random.nextInt(3000);
                    PoetryContent poetryContent = poetryContentMapper.selectByPrimaryKey(randomId);
                    RecommendListVo recommendVo = new RecommendListVo();
                    recommendVo.setAuthor(poetryContent.getAuthor());
                    recommendVo.setPoetryId(poetryContent.getId());
                    recommendVo.setPoetryAnnotation(poetryContent.getPoetryAnnotation());//诗词注释
                    recommendVo.setPoetryBackground(poetryContent.getPoetryBackground());
                    recommendVo.setPoetryContent(poetryContent.getPoetryContent());
                    recommendVo.setPoetryTranslate(poetryContent.getPoetryTranslate());//诗词翻译
                    recommendVo.setPoetryName(poetryContent.getPoetryName());
                    Author author = authorMapper.selectByPrimaryKey(poetryContent.getAuthorId());
                    recommendVo.setDynasty(author.getAuthorDynasty());

                    recommendListVos.add(recommendVo);//将返回的诗词放入列表中

            }

        }else if(firstAuthorId !=0 && secondAuthorId ==0){ //如果第一喜好作者有，第二没有

            PoetryContentExample poetryContentExample = new PoetryContentExample();
            poetryContentExample.createCriteria().andAuthorIdEqualTo(firstAuthorId);
            List<PoetryContent> firstAuthorLikeList = poetryContentMapper.selectByExample(poetryContentExample);
            if(firstAuthorLikeList.size() >= 2){
                for(int i = 0;i<2;i++){
                    PoetryContent poetryContent = firstAuthorLikeList.get(random.nextInt(firstAuthorLikeList.size()));
                    RecommendListVo recommendVo = new RecommendListVo();
                    recommendVo.setAuthor(poetryContent.getAuthor());
                    recommendVo.setPoetryId(poetryContent.getId());
                    recommendVo.setPoetryAnnotation(poetryContent.getPoetryAnnotation());//诗词注释
                    recommendVo.setPoetryBackground(poetryContent.getPoetryBackground());
                    recommendVo.setPoetryContent(poetryContent.getPoetryContent());
                    recommendVo.setPoetryTranslate(poetryContent.getPoetryTranslate());//诗词翻译
                    recommendVo.setPoetryName(poetryContent.getPoetryName());
                    Author author = authorMapper.selectByPrimaryKey(poetryContent.getAuthorId());
                    recommendVo.setDynasty(author.getAuthorDynasty());

                    recommendListVos.add(recommendVo);//将返回的诗词放入列表中
                }
            }else {
                for (int i = 0; i < 2; i++)
                {
                    long randomId = random.nextInt(3000);
                    PoetryContent poetryContent = poetryContentMapper.selectByPrimaryKey(randomId);
                    RecommendListVo recommendVo = new RecommendListVo();
                    recommendVo.setAuthor(poetryContent.getAuthor());
                    recommendVo.setPoetryId(poetryContent.getId());
                    recommendVo.setPoetryAnnotation(poetryContent.getPoetryAnnotation());//诗词注释
                    recommendVo.setPoetryBackground(poetryContent.getPoetryBackground());
                    recommendVo.setPoetryContent(poetryContent.getPoetryContent());
                    recommendVo.setPoetryTranslate(poetryContent.getPoetryTranslate());//诗词翻译
                    recommendVo.setPoetryName(poetryContent.getPoetryName());
                    Author author = authorMapper.selectByPrimaryKey(poetryContent.getAuthorId());
                    recommendVo.setDynasty(author.getAuthorDynasty());

                    recommendListVos.add(recommendVo);//将返回的诗词放入列表中
                }
            }

                long randomId = random.nextInt(3000);
                PoetryContent poetryContent = poetryContentMapper.selectByPrimaryKey(randomId);
                RecommendListVo recommendVo = new RecommendListVo();
                recommendVo.setAuthor(poetryContent.getAuthor());
                recommendVo.setPoetryId(poetryContent.getId());
                recommendVo.setPoetryAnnotation(poetryContent.getPoetryAnnotation());//诗词注释
                recommendVo.setPoetryBackground(poetryContent.getPoetryBackground());
                recommendVo.setPoetryContent(poetryContent.getPoetryContent());
                recommendVo.setPoetryTranslate(poetryContent.getPoetryTranslate());//诗词翻译
                recommendVo.setPoetryName(poetryContent.getPoetryName());
                Author author = authorMapper.selectByPrimaryKey(poetryContent.getAuthorId());
                recommendVo.setDynasty(author.getAuthorDynasty());

                recommendListVos.add(recommendVo);//将返回的诗词放入列表中


        } else if(firstAuthorId ==0 && secondAuthorId == 0)
        {
            for(int i = 0;i<3;i++)
            {
                long randomId = random.nextInt(3000);
                PoetryContent poetryContent = poetryContentMapper.selectByPrimaryKey(randomId);
                RecommendListVo recommendVo = new RecommendListVo();
                recommendVo.setAuthor(poetryContent.getAuthor());
                recommendVo.setPoetryId(poetryContent.getId());
                recommendVo.setPoetryAnnotation(poetryContent.getPoetryAnnotation());//诗词注释
                recommendVo.setPoetryBackground(poetryContent.getPoetryBackground());
                recommendVo.setPoetryContent(poetryContent.getPoetryContent());
                recommendVo.setPoetryTranslate(poetryContent.getPoetryTranslate());//诗词翻译
                recommendVo.setPoetryName(poetryContent.getPoetryName());
                Author author = authorMapper.selectByPrimaryKey(poetryContent.getAuthorId());
                recommendVo.setDynasty(author.getAuthorDynasty());

                recommendListVos.add(recommendVo);//将返回的诗词放入列表中
            }
        }

        //根据喜好朝代

        String dynasty = dynastyMapper.selectByPrimaryKey(firstDynastyId).getDynasty();

        AuthorExample authorExample = new AuthorExample();
        authorExample.createCriteria().andAuthorDynastyEqualTo(dynasty);
        List<Author> authors = authorMapper.selectByExample(authorExample);
        if(firstDynastyId != 0 && authors.size() != 0){


            PoetryContentExample poetryContentExample = new PoetryContentExample();

            for (int i = 0; i < 3;i++){
                poetryContentExample.createCriteria().andAuthorIdEqualTo( authors.get(random.nextInt(authors.size())).getId());
                List<PoetryContent> poetryList = poetryContentMapper.selectByExample(poetryContentExample);
                PoetryContent poetryContent = poetryList.get(random.nextInt(poetryList.size()));
                RecommendListVo recommendVo = new RecommendListVo();
                recommendVo.setAuthor(poetryContent.getAuthor());
                recommendVo.setPoetryId(poetryContent.getId());
                recommendVo.setPoetryAnnotation(poetryContent.getPoetryAnnotation());//诗词注释
                recommendVo.setPoetryBackground(poetryContent.getPoetryBackground());
                recommendVo.setPoetryContent(poetryContent.getPoetryContent());
                recommendVo.setPoetryTranslate(poetryContent.getPoetryTranslate());//诗词翻译
                recommendVo.setPoetryName(poetryContent.getPoetryName());
                Author author = authorMapper.selectByPrimaryKey(poetryContent.getAuthorId());
                recommendVo.setDynasty(author.getAuthorDynasty());

                recommendListVos.add(recommendVo);//将返回的诗词放入列表中




            }


        }else{
            for(int i = 0;i<3;i++)
            {
                long randomId = random.nextInt(3000);
                PoetryContent poetryContent = poetryContentMapper.selectByPrimaryKey(randomId);
                RecommendListVo recommendVo = new RecommendListVo();
                recommendVo.setAuthor(poetryContent.getAuthor());
                recommendVo.setPoetryId(poetryContent.getId());
                recommendVo.setPoetryAnnotation(poetryContent.getPoetryAnnotation());//诗词注释
                recommendVo.setPoetryBackground(poetryContent.getPoetryBackground());
                recommendVo.setPoetryContent(poetryContent.getPoetryContent());
                recommendVo.setPoetryTranslate(poetryContent.getPoetryTranslate());//诗词翻译
                recommendVo.setPoetryName(poetryContent.getPoetryName());
                Author author = authorMapper.selectByPrimaryKey(poetryContent.getAuthorId());
                recommendVo.setDynasty(author.getAuthorDynasty());

                recommendListVos.add(recommendVo);//将返回的诗词放入列表中
            }
        }


        int circulation = 10-recommendListVos.size();
        for(int i =0;i<circulation;i++)
        {
//            System.out.println(10-recommendListVos.size());
            long randomId = random.nextInt(3000);
            PoetryContent poetryContent = poetryContentMapper.selectByPrimaryKey(randomId);
            RecommendListVo recommendVo = new RecommendListVo();
            recommendVo.setAuthor(poetryContent.getAuthor());
            recommendVo.setPoetryId(poetryContent.getId());
            recommendVo.setPoetryAnnotation(poetryContent.getPoetryAnnotation());//诗词注释
            recommendVo.setPoetryBackground(poetryContent.getPoetryBackground());
            recommendVo.setPoetryContent(poetryContent.getPoetryContent());
            recommendVo.setPoetryTranslate(poetryContent.getPoetryTranslate());//诗词翻译
            recommendVo.setPoetryName(poetryContent.getPoetryName());
            Author author = authorMapper.selectByPrimaryKey(poetryContent.getAuthorId());
            recommendVo.setDynasty(author.getAuthorDynasty());

            recommendListVos.add(recommendVo);//将返回的诗词放入列表中
        }


        return recommendListVos;
    }

    @Override
    public RecordBrowsingResult recordBrowsing(Long poetryId) {
        User currentUser = SecurityUtils.getCurrentUser();//看看当前用户是否登录
        if(currentUser == null){
            return RecordBrowsingResult.USER_NOT_LOGIN;
        }
        else{
            BrowsingHistory browsingHistory = new BrowsingHistory();
            browsingHistory.setPoetryId(poetryId);
            browsingHistory.setUserId(currentUser.getId());
            Date date = new Date();
            browsingHistory.setCreateTime(date);
            browsingHistory.setUpdateTime(date);
            if(browsingHistoryMapper.insertSelective(browsingHistory)<= 0)
            {
                return RecordBrowsingResult.REC_FAILED;
            }
            return RecordBrowsingResult.REC_SUCCESS;
        }

    }


    @Override
    public CollectResult collectPoetry(Long poetryId) {
        User currentUser = SecurityUtils.getCurrentUser();//看看当前用户是否登录
        Long userId = currentUser.getId();
        if(currentUser!=null){
            UserCollectExample userCollectExample = new UserCollectExample();
            userCollectExample.createCriteria().andUserIdEqualTo(userId).andPoetryIdEqualTo(poetryId).andIsDeleteNotEqualTo(1);
            List<UserCollect> userCollects = userCollectMapper.selectByExample(userCollectExample);
            if(userCollects.size()==0){
                UserCollect userCollect = new UserCollect();
                userCollect.setUserId(currentUser.getId());
                Date date = new Date();
                userCollect.setCreateTime(date);
                userCollect.setPoetryId(poetryId);
                userCollect.setIsDelete(2);
                if(userCollectMapper.insertSelective(userCollect)>0){
                    return CollectResult.SUC_COLLECT;
                }
            }else{
                UserCollect userCollect = new UserCollect();
                userCollect.setIsDelete(1);
                if(userCollectMapper.updateByExampleSelective(userCollect,userCollectExample)>0)
                {
                    return CollectResult.CAN_COLLECT;
                }

            }
        }
    return CollectResult.NOT_LOGIN;

    }
    //用户修改信息
    @Override
    public int updateUserMessage(UserMessageParam userMessageParam) {
        User currentUser = SecurityUtils.getCurrentUser();

        if(currentUser != null){
            System.out.println("nihao1nihao1");
            User user = new User();
            user.setId(currentUser.getId());
            user.setUserName(userMessageParam.getUserName());
            user.setUserIntroduce(userMessageParam.getUserIntroduce());
            user.setGender(userMessageParam.getGender());
            user.setImgUrl(userMessageParam.getImgUrl());
            user.setBirthday(userMessageParam.getBirthday());
            user.setEducationBackground(userMessageParam.getEducation_background());
            //user准备完毕

            //获取用户输入的作者id
            AuthorExample authorExample = new AuthorExample();
            authorExample.createCriteria().andAuthorNameEqualTo(userMessageParam.getPoetry_author());
            List<Author> authors = authorMapper.selectByExample(authorExample);
            DynastyExample dynastyExample = new DynastyExample();
            dynastyExample.createCriteria().andDynastyEqualTo(userMessageParam.getPoetry_dynasty());
            List<Dynasty> dynasties = dynastyMapper.selectByExample(dynastyExample);
            if(authors.size()>0 && dynasties.size()>0){//如果查到用户填写的作者和朝代id
                UserLikeExample userLikeExample = new UserLikeExample();
                userLikeExample.createCriteria().andUserIdEqualTo(currentUser.getId()).andIsUserWriteEqualTo(1);
                if(userLikeMapper.selectByExample(userLikeExample).size()>0){//如果用户有填写过
                    UserLike userLike = new UserLike();
                    userLike.setPoetryDynastyId(dynasties.get(0).getId());
                    userLike.setPoetryAuthorId(authors.get(0).getId());
                    Date date = new Date();
                    userLike.setUpdateTime(date);
                    if(userLikeMapper.updateByExampleSelective(userLike,userLikeExample)>0){
                        userMapper.updateByPrimaryKeySelective(user);
                        return 1;
                    }

                }else{//如果用户没有填写过喜好的诗词
                    UserLike userLike = new UserLike();
                    userLike.setUserId(currentUser.getId());
                    userLike.setPoetryDynastyId(dynasties.get(0).getId());
                    userLike.setPoetryAuthorId(authors.get(0).getId());
                    userLike.setIsUserWrite(1);
                    Date date = new Date();
                    userLike.setCreateTime(date);
                    if(userLikeMapper.insertSelective(userLike)>0){
                        userMapper.updateByPrimaryKeySelective(user);
                    }


                }


            }else
            {
                userMapper.updateByPrimaryKeySelective(user);
                return 2;//查找不到用户填写的作者或朝代
            }

        }



        return 0;
    }

    @Override
    public List<CollectVo> getCollectList() {
        List<CollectVo> collectList =new ArrayList<>();
        User currentUser = SecurityUtils.getCurrentUser();
        if(currentUser!= null){
            Long userId = currentUser.getId();
            UserCollectExample userCollectExample = new UserCollectExample();
            userCollectExample.createCriteria().andUserIdEqualTo(userId);
            List<UserCollect> userCollects = userCollectMapper.selectByExample(userCollectExample);
            for(UserCollect collect:userCollects)
            {
                PoetryContent poetryContent = poetryContentMapper.selectByPrimaryKey(collect.getPoetryId());
                CollectVo collectVo = new CollectVo();
                collectVo.setCollectTime(poetryContent.getCreateTime());
                collectVo.setAuthor(poetryContent.getAuthor());
                collectVo.setPoetryId(collect.getPoetryId());
                collectVo.setPoetryName(poetryContent.getPoetryName());
                collectVo.setPoetryContent(poetryContent.getPoetryContent());
                collectList.add(collectVo);
            }

        }

        return collectList;
    }
}
