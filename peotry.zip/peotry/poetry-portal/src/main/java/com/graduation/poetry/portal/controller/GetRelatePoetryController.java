package com.graduation.poetry.portal.controller;


import com.graduation.poetry.common.api.CommonResult;
import com.graduation.poetry.model.PoetryContent;
import com.graduation.poetry.model.PoetryTypeRelation;
import com.graduation.poetry.portal.model.vo.RecommendListVo;
import com.graduation.poetry.portal.service.GetRelatedPoetryService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin
@Api(value = "GetRelatePoetryController",description = "获取诗词接口")
@RestController
@RequestMapping("/getRelatePoetry")
public class GetRelatePoetryController {

    @Autowired
    private GetRelatedPoetryService getRelatedPoetryService;

    @ApiOperation("查询接口")
    @PostMapping("/searchPoetry")
    public CommonResult<List<PoetryContent>> searchPoetry(@ApiParam("搜索关键词") @RequestParam("keyword") String keyword){
        List<PoetryContent> poetryContentList = getRelatedPoetryService.searchPoetry(keyword);
        if(poetryContentList!=null){
            return CommonResult.success(poetryContentList,"查询成功");
        }

        return CommonResult.failed("未查询到数据");

    }

    @ApiOperation("根据朝代获取诗词")
    @PostMapping("/getPoetryByDynasty")
    public CommonResult<List<PoetryContent>> getPoetryByDynastyId(@ApiParam("朝代")@RequestParam("dynasty") String dynasty){
        List<PoetryContent> poetrys = getRelatedPoetryService.getPoetryByDynastyId(dynasty);
        if(poetrys.size()>0){
            return CommonResult.success(poetrys,"返回成功");
        }
        return CommonResult.failed("返回失败");

    }

    @ApiOperation("根据作者id获取诗词")
    @PostMapping("/getPoetryByAuthorId")
    public CommonResult<List<PoetryContent>> getPoetryByAuthorId(@ApiParam("作者id")@RequestParam("authorId") Long authorId){
        List<PoetryContent> poetrys = getRelatedPoetryService.getPoetryByAuthorId(authorId);
        if(poetrys.size()>0){
            return CommonResult.success(poetrys,"返回成功");
        }
        return CommonResult.failed("返回失败");

    }

    @ApiOperation("根据诗词id获取诗词")
    @PostMapping("/getPoetryByPoetryId")
    public CommonResult<RecommendListVo> getPoetryByPoetryId(@ApiParam("诗词id")@RequestParam("poetryId") Long poetryId){
        RecommendListVo poetry = getRelatedPoetryService.getPoetryByPoetryId(poetryId);
        if(poetry!=null){
            return CommonResult.success(poetry,"返回成功");

        }
        return CommonResult.failed("未找到诗词");


    }

    @ApiOperation("返回练习诗词列表")
    @PostMapping("/getPracticePoetry")
    public CommonResult<List<PoetryTypeRelation>> getPracticePoetry(@ApiParam("年级")@RequestParam("grade")String grade){
        List<PoetryTypeRelation> practicePoetry = getRelatedPoetryService.getPracticePoetry(grade);
        if(practicePoetry.size()>0){
            return CommonResult.success(practicePoetry,"返回成功");
        }
        return CommonResult.failed("返回失败");
    }
}
