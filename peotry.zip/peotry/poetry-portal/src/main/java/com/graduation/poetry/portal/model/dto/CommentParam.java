package com.graduation.poetry.portal.model.dto;

import io.swagger.annotations.ApiModelProperty;

public class CommentParam {
    @ApiModelProperty("该评论是否删除（是为1，否为2")
    private int isDelete;
    @ApiModelProperty("该评论是否为回复（是为1，否为2")
    private int isReply;
    @ApiModelProperty("评论内容")
    private String poetryDiscuss;
    @ApiModelProperty("诗词id")
    private Long poetryId;

    @ApiModelProperty("回复的评论的id")
    private Long replyDiscussId;

    public CommentParam() {
    }

    @Override
    public String toString() {
        return "CommentParam{" +
                "isDelete=" + isDelete +
                ", isReply=" + isReply +
                ", poetryDiscuss='" + poetryDiscuss + '\'' +
                ", poetryId=" + poetryId +

                ", replyDiscussId=" + replyDiscussId +
                '}';
    }

    public int getIsDelete() {
        return isDelete;
    }

    public void setIsDelete(int isDelete) {
        this.isDelete = isDelete;
    }

    public int getIsReply() {
        return isReply;
    }

    public void setIsReply(int isReply) {
        this.isReply = isReply;
    }

    public String getPoetryDiscuss() {
        return poetryDiscuss;
    }

    public void setPoetryDiscuss(String poetryDiscuss) {
        this.poetryDiscuss = poetryDiscuss;
    }

    public Long getPoetryId() {
        return poetryId;
    }

    public void setPoetryId(Long poetryId) {
        this.poetryId = poetryId;
    }



    public Long getReplyDiscussId() {
        return replyDiscussId;
    }

    public void setReplyDiscussId(Long replyDiscussId) {
        this.replyDiscussId = replyDiscussId;
    }
}
