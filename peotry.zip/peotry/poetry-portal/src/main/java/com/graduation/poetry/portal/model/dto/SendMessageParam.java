package com.graduation.poetry.portal.model.dto;

import ch.qos.logback.classic.spi.EventArgUtil;
import io.swagger.annotations.ApiModelProperty;

public class SendMessageParam {

    @ApiModelProperty(value = "发送用户id")
    private Long userId;
    @ApiModelProperty(value = "接收用户id")
    private Long friendId;
    @ApiModelProperty(value = "消息内容")
    private String messageContent;
    @ApiModelProperty(value = "是否为分享诗词的消息（是分享诗词为1，不是为2）")
    private int isSharePoetry;//是分享诗词为1，不是为2
    @ApiModelProperty(value = "分享的诗词id")
    private Long sharePoetryId;

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public Long getFriendId() {
        return friendId;
    }

    public void setFriendId(Long friendId) {
        this.friendId = friendId;
    }

    public String getMessageContent() {
        return messageContent;
    }

    public void setMessageContent(String messageContent) {
        this.messageContent = messageContent;
    }

    public int getIsSharePoetry() {
        return isSharePoetry;
    }

    public void setIsSharePoetry(int isSharePoetry) {
        this.isSharePoetry = isSharePoetry;
    }

    public Long getSharePoetryId() {
        return sharePoetryId;
    }

    public void setSharePoetryId(Long sharePoetryId) {
        this.sharePoetryId = sharePoetryId;
    }

    @Override
    public String toString() {
        return "sendMessageParam{" +
                "userId=" + userId +
                ", friendId=" + friendId +
                ", messageContent='" + messageContent + '\'' +
                ", isSharePoetry=" + isSharePoetry +
                ", sharePoetryId=" + sharePoetryId +
                '}';
    }
}
