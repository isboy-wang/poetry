package com.graduation.poetry.portal.controller;


import com.graduation.poetry.common.api.CommonResult;
import com.graduation.poetry.model.PoetryDiscuss;
import com.graduation.poetry.portal.model.dto.CommentParam;
import com.graduation.poetry.portal.model.vo.CommentUserVo;
import com.graduation.poetry.portal.service.PoetryCommentService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.models.auth.In;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.xml.stream.events.Comment;
import java.util.List;

@CrossOrigin
@Api(value = "PoetryCommentController",description = "诗词评论接口")
@RestController
@RequestMapping("/comment")
public class PoetryCommentController {


    @Autowired
    private PoetryCommentService poetryCommentService;

    @ApiOperation("记录诗词评论接口")
    @PostMapping("/recordComment")
    public CommonResult<Integer> recordComment(@ApiParam("评论对象") @RequestBody CommentParam comment){
        int i = poetryCommentService.recordComment(comment);
        if(i==1){
            return CommonResult.success(1,"评论成功");
        }
        return CommonResult.failed("评论失败");

    }

    @ApiOperation("返回诗词评论列表")
    @PostMapping("/getCommentList")
    public CommonResult<List<CommentUserVo>> getCommentList(@ApiParam("诗词id")@RequestParam("poetryId")Long poetryId){
        List<CommentUserVo> commentList = poetryCommentService.getCommentList(poetryId);
        if(commentList.size()>0){
            return CommonResult.success(commentList,"返回成功");
        }
        return CommonResult.failed("暂无评论");

    }

    @ApiOperation("返回回复列表")
    @PostMapping("/getReplyList")
    public CommonResult<List<CommentUserVo>> getReplyList(@ApiParam("评论id")@RequestParam("commentId")Long commentId){
        List<CommentUserVo> replyList = poetryCommentService.getReplyList(commentId);
        if(replyList.size()>0){
            return CommonResult.success(replyList,"返回成功");
        }
        return CommonResult.failed("暂无评论");

    }

    @ApiOperation("点赞接口")
    @PostMapping("/support")
    public CommonResult<Integer> support(@ApiParam("评论id")@RequestParam("commentId")Long commentId){
        int support = poetryCommentService.support(commentId);

        if(support==1){
            return CommonResult.success(1,"点赞成功");
        }
        return CommonResult.failed("点赞失败");
    }

    @ApiOperation("举报接口")
    @PostMapping("/report")
    public CommonResult<Integer> report(@ApiParam("评论id")@RequestParam("commentId")Long commentId,
                                        @ApiParam("用户id")@RequestParam("userId")Long userId){
        int report = poetryCommentService.report(commentId, userId);
        if(report>0){
            return CommonResult.success(1,"举报成功");
        }
        return CommonResult.failed("举报失败");
    }
}
