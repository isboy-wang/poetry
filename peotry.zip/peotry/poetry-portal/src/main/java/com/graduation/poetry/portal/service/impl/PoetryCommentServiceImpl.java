package com.graduation.poetry.portal.service.impl;

import com.graduation.poetry.mapper.PoetryDiscussMapper;
import com.graduation.poetry.mapper.UserMapper;
import com.graduation.poetry.model.PoetryDiscuss;
import com.graduation.poetry.model.PoetryDiscussExample;
import com.graduation.poetry.model.User;
import com.graduation.poetry.portal.model.dto.CommentParam;
import com.graduation.poetry.portal.model.vo.CommentUserVo;
import com.graduation.poetry.portal.service.PoetryCommentService;
import com.graduation.poetry.portal.util.SecurityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Service
public class PoetryCommentServiceImpl implements PoetryCommentService {
    @Autowired
    private PoetryDiscussMapper poetryDiscussMapper;
    @Autowired
    private UserMapper userMapper;

    //记录用户评论
    @Override
    public int recordComment(CommentParam comment) {
        User currentUser = SecurityUtils.getCurrentUser();
        if(currentUser!=null){
            PoetryDiscuss poetryDiscuss = new PoetryDiscuss();
            poetryDiscuss.setUserId(currentUser.getId());
            poetryDiscuss.setPoetryId(comment.getPoetryId());
            poetryDiscuss.setPoetryDiscuss(comment.getPoetryDiscuss());
            Date date = new Date();
            poetryDiscuss.setCreateTime(date);
            poetryDiscuss.setIsDelete(comment.getIsDelete());
            poetryDiscuss.setIsReply(comment.getIsReply());
            poetryDiscuss.setReplyDiscussId(comment.getReplyDiscussId());
            poetryDiscuss.setBeReport(2);
            if(poetryDiscussMapper.insertSelective(poetryDiscuss) >0){
                return 1;
            }

        }
        return 0;
    }

    @Override
    public List<CommentUserVo> getCommentList(Long poetryId) {
        List<CommentUserVo> commentList = new ArrayList<>();
        PoetryDiscussExample poetryDiscussExample = new PoetryDiscussExample();
        poetryDiscussExample.createCriteria().andPoetryIdEqualTo(poetryId).andIsDeleteNotEqualTo(1).andIsReplyNotEqualTo(1);
        List<PoetryDiscuss> poetryDiscusses = poetryDiscussMapper.selectByExample(poetryDiscussExample);
        for(PoetryDiscuss comment:poetryDiscusses){
            CommentUserVo commentUserVo = new CommentUserVo();
            commentUserVo.setCommentId(comment.getId());
            commentUserVo.setCommentContent(comment.getPoetryDiscuss());
            commentUserVo.setUserId(comment.getUserId());
            commentUserVo.setCreatDate(comment.getCreateTime());
            commentUserVo.setSupportNum(comment.getSupportNum());
            User user = userMapper.selectByPrimaryKey(comment.getUserId());
            commentUserVo.setUserName(user.getUserName());
            commentUserVo.setImgUrl(user.getImgUrl());
            commentList.add(commentUserVo);
        }


        return commentList;
    }

    @Override
    public List<CommentUserVo> getReplyList(Long commentId) {
        List<CommentUserVo> commentList = new ArrayList<>();
        PoetryDiscussExample poetryDiscussExample = new PoetryDiscussExample();
        poetryDiscussExample.createCriteria().andIsReplyEqualTo(1).andIsDeleteNotEqualTo(1).andReplyDiscussIdEqualTo(commentId);
        List<PoetryDiscuss> poetryDiscusses = poetryDiscussMapper.selectByExample(poetryDiscussExample);
        for(PoetryDiscuss comment:poetryDiscusses)
        {
            CommentUserVo commentUserVo = new CommentUserVo();
            commentUserVo.setCommentId(comment.getId());
            commentUserVo.setCommentContent(comment.getPoetryDiscuss());
            commentUserVo.setUserId(comment.getUserId());
            commentUserVo.setCreatDate(comment.getCreateTime());
            commentUserVo.setReplyDiscussId(comment.getReplyDiscussId());
//            commentUserVo.setSupportNum(comment.getSupportNum());
            User user = userMapper.selectByPrimaryKey(comment.getUserId());
            commentUserVo.setUserName(user.getUserName());
            commentUserVo.setImgUrl(user.getImgUrl());
            commentList.add(commentUserVo);
        }
        return commentList;
    }

    @Override
    public int support(Long commentId) {
        PoetryDiscuss poetryDiscuss = poetryDiscussMapper.selectByPrimaryKey(commentId);
        Long supportNum = poetryDiscuss.getSupportNum();
        User currentUser = SecurityUtils.getCurrentUser();
        if(currentUser!=null){
            supportNum++;
            PoetryDiscuss updatePoetryDiscuss = new PoetryDiscuss();
            updatePoetryDiscuss.setId(commentId);
            updatePoetryDiscuss.setSupportNum(supportNum);
            if(poetryDiscussMapper.updateByPrimaryKeySelective(updatePoetryDiscuss)>0){
                return 1;
            }
        }

        return 0;
    }

    @Override
    public int report(Long commentId, Long userId) {
        User user = new User();
        user.setId(userId);
        user.setBeReport(1);

        PoetryDiscuss poetryDiscuss = new PoetryDiscuss();
        poetryDiscuss.setId(commentId);
        poetryDiscuss.setBeReport(1);
        if(poetryDiscussMapper.updateByPrimaryKeySelective(poetryDiscuss)>0 &&userMapper.updateByPrimaryKeySelective(user)>0){
            return 1;
        }
        return 0;
    }
}
