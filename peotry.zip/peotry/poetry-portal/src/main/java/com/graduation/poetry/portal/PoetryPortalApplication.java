package com.graduation.poetry.portal;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;

@SpringBootApplication(scanBasePackages = "com.graduation.poetry")
@MapperScan(basePackages = {"com.graduation.poetry.mapper","com.graduation.poetry.portal.dao"})
public class PoetryPortalApplication {
    public static void main(String[] args) {
        SpringApplication.run(PoetryPortalApplication.class,args);
    }
}
