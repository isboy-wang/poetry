package com.graduation.poetry.enums;

import com.graduation.poetry.common.api.IErrorCode;

public enum RecordBrowsingResult implements IErrorCode {
    REC_SUCCESS(0, "记录成功"),
    USER_NOT_LOGIN(1, "用户未登录"),
    REC_FAILED(2,"记录失败");
    private long code;
    private String message;


    RecordBrowsingResult(long code, String message) {
        this.code = code;
        this.message = message;
    }

    @Override
    public long getCode() {
        return code;
    }

    @Override
    public String getMessage() {
        return message;
    }
}
