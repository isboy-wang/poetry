package com.graduation.poetry.portal.service;

import java.util.List;
import java.util.Map;

public interface SentenceService {

    /**
     * 随机生成六个句子和出处的键值对返回
     * @return返回六个句子键值对
     */
    Map<String,String> randomSentence();
}
