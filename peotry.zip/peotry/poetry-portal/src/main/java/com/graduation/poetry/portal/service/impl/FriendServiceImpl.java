package com.graduation.poetry.portal.service.impl;

import com.graduation.poetry.mapper.MessageMapper;
import com.graduation.poetry.mapper.UserFriendRelationMapper;
import com.graduation.poetry.mapper.UserMapper;
import com.graduation.poetry.model.*;
import com.graduation.poetry.portal.model.dto.SendMessageParam;
import com.graduation.poetry.portal.service.FriendService;
import com.graduation.poetry.portal.util.SecurityUtils;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Service
public class FriendServiceImpl implements FriendService {

    @Autowired
    private MessageMapper messageMapper;

    @Autowired
    private UserFriendRelationMapper userFriendRelationMapper;

    @Autowired
    private UserMapper userMapper;

     //记录用户聊天内容
    @Override
    public int sendMessage(SendMessageParam sendMessageParam) {

        //判断好友表里是不是已经有好友记录了
        UserFriendRelationExample userFriendRelationExample1 = new UserFriendRelationExample();
        userFriendRelationExample1.createCriteria().andUserIdEqualTo(sendMessageParam.getUserId()).andFriendIdEqualTo(sendMessageParam.getFriendId());
        UserFriendRelationExample userFriendRelationExample2 = new UserFriendRelationExample();
        userFriendRelationExample2.createCriteria().andUserIdEqualTo(sendMessageParam.getFriendId()).andFriendIdEqualTo(sendMessageParam.getUserId());
        if(userFriendRelationMapper.countByExample(userFriendRelationExample1)==0 && userFriendRelationMapper.countByExample(userFriendRelationExample2)==0){
            UserFriendRelation userFriendRelation = new UserFriendRelation();
            userFriendRelation.setUserId(sendMessageParam.getUserId());
            userFriendRelation.setFriendId(sendMessageParam.getFriendId());
            Date date = new Date();
            userFriendRelation.setCreateTime(date);
            userFriendRelationMapper.insertSelective(userFriendRelation);
        }

        if(sendMessageParam.getUserId()!=null &&sendMessageParam.getFriendId()!=null){
            Message message = new Message();
            message.setSendUserId(sendMessageParam.getUserId());
            message.setReceiveUserId(sendMessageParam.getFriendId());
            message.setMessageContent(sendMessageParam.getMessageContent());
            Date date = new Date();
            message.setCreateTime(date);
            message.setIsSharePoetry(sendMessageParam.getIsSharePoetry());
            if(sendMessageParam.getIsSharePoetry() == 1){
                message.setSharePoetryId(sendMessageParam.getSharePoetryId());
            }
            if(messageMapper.insertSelective(message)>0)
                return 1;
        }
        return 0;
    }

    //返回用户聊天内容


    @Override
    public List<Message> getUserMessageById(Long userId, Long friendId) {
        List<Message> messages = new ArrayList<>();
        MessageExample UserMessageExample = new MessageExample();
        UserMessageExample.createCriteria().andSendUserIdEqualTo(userId).andReceiveUserIdEqualTo(friendId);
        List<Message> userMessages = messageMapper.selectByExample(UserMessageExample);
        MessageExample friendMessageExample = new MessageExample();
        friendMessageExample.createCriteria().andSendUserIdEqualTo(friendId).andReceiveUserIdEqualTo(userId);
        List<Message> friendMessages = messageMapper.selectByExample(friendMessageExample);
        int i = 0;
        int j = 0;

        while(i<userMessages.size() || j<friendMessages.size()){
            if(i>=userMessages.size()){
                while(j<friendMessages.size()){
                    messages.add(friendMessages.get(j));
                    j++;
                }
                break;
            }
            if(j>=friendMessages.size()){
                while (i<userMessages.size()){
                    messages.add(userMessages.get(i));
                    i++;
                }
                break;
            }
            if(userMessages.get(i).getCreateTime().before(friendMessages.get(j).getCreateTime())){
                messages.add(userMessages.get(i));
                i++;
            }
            else
            {
                messages.add(friendMessages.get(j));
                j++;
            }

        }

        return messages;
    }



    //获取好友列表（有发送过消息，就是好友）
    @Override
    public List<User> getFriendList() {
        User currentUser = SecurityUtils.getCurrentUser();
        Long userId = currentUser.getId();
        UserFriendRelationExample userFriendRelationExample1 = new UserFriendRelationExample();
        userFriendRelationExample1.createCriteria().andFriendIdEqualTo(userId);
        UserFriendRelationExample userFriendRelationExample2 = new UserFriendRelationExample();
        userFriendRelationExample2.createCriteria().andUserIdEqualTo(userId);
        List<UserFriendRelation> userFriendRelations1 = userFriendRelationMapper.selectByExample(userFriendRelationExample1);
        List<UserFriendRelation> userFriendRelations2 = userFriendRelationMapper.selectByExample(userFriendRelationExample2);
        List<Long> friendIds = new ArrayList<>();
        for(UserFriendRelation relation1:userFriendRelations1){
            friendIds.add(relation1.getUserId());
        }
        for(UserFriendRelation relation2:userFriendRelations2){
            friendIds.add(relation2.getFriendId());
        }

        List<User> friends = new ArrayList<>();
        for(Long friendId:friendIds){
            friends.add(userMapper.selectByPrimaryKey(friendId));

        }
        return friends;
    }


    //搜索好友
    @Override
    public User searchFriend(String userName) {

        UserExample example = new UserExample();
        example.createCriteria().andUserNameEqualTo(userName);
        List<User> users = userMapper.selectByExample(example);
        if(users.size()>0){
            User user = users.get(0);
            User friend = new User();
            friend.setId(user.getId());
            friend.setUserName(user.getUserName());
            friend.setImgUrl(user.getImgUrl());
            friend.setGender(user.getGender());
            friend.setUserIntroduce(user.getUserIntroduce());
            friend.setOccupation(user.getOccupation());

            return friend;
        }
        return null;
    }


    @Override
    public int sharePoetry(Long poetryId, Long friendId) {

        User currentUser = SecurityUtils.getCurrentUser();
        if(currentUser!= null){
            Message message = new Message();
            message.setIsSharePoetry(1);
            message.setSendUserId(currentUser.getId());
            message.setReceiveUserId(friendId);
            Date date = new Date();
            message.setCreateTime(date);
            message.setSharePoetryId(poetryId);

            if(messageMapper.insertSelective(message)>0){
                return 1;
            }
        }
        return 0;
    }
}
