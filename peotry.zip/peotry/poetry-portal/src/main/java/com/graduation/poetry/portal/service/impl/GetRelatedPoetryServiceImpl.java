package com.graduation.poetry.portal.service.impl;

import com.graduation.poetry.mapper.*;
import com.graduation.poetry.model.*;
import com.graduation.poetry.portal.dao.PoetryMapper;
import com.graduation.poetry.portal.model.vo.RecommendListVo;
import com.graduation.poetry.portal.service.GetRelatedPoetryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class GetRelatedPoetryServiceImpl implements GetRelatedPoetryService {

    @Autowired
    private PoetryContentMapper poetryContentMapper;

    @Autowired
    private PoetryMapper poetryMapper;

    @Autowired
    private AuthorMapper authorMapper;

    @Autowired
    private DynastyMapper dynastyMapper;

    @Autowired
    private PoetryTypeMapper poetryTypeMapper;

    @Autowired
    private PoetryTypeRelationMapper poetryTypeRelationMapper;
    @Override
    public List<PoetryContent> searchPoetry(String keyword) {
        //keyword可能是作者名，可能是诗词名
        List<PoetryContent> poetryList = new ArrayList<>();
        PoetryContentExample poetryContentExample = new PoetryContentExample();
        poetryContentExample.createCriteria().andAuthorEqualTo(keyword);
        if(poetryContentMapper.selectByExample(poetryContentExample).size() > 0){
            poetryList = poetryContentMapper.selectByExample(poetryContentExample);
            return poetryList;
        }
//        PoetryContentExample example = new PoetryContentExample();
//        example.createCriteria().andPoetryNameLike(keyword);
//        if(poetryContentMapper.selectByExample(example).size()>0){
//            poetryList = poetryContentMapper.selectByExample(example);
//            return poetryList;
//        }
        poetryList = poetryMapper.getPoetryByKeyword(keyword);
        if(poetryList.size()>0){
            return poetryList;
        }
        return null;
    }

    @Override
    public List<PoetryContent> getPoetryByDynastyId(String dynasty) {
        List<PoetryContent> poetrys = new ArrayList<>();

            AuthorExample authorExample = new AuthorExample();
            authorExample.createCriteria().andAuthorDynastyEqualTo(dynasty);
            if(authorMapper.selectByExample(authorExample).size()>0){
                List<Author> authors = authorMapper.selectByExample(authorExample);
                for(Author author:authors){
                    PoetryContentExample poetryContentExample = new PoetryContentExample();
                    poetryContentExample.createCriteria().andAuthorIdEqualTo(author.getId());
                    if(poetryContentMapper.selectByExample(poetryContentExample).size()>0){
                        List<PoetryContent> poetryContentList = poetryContentMapper.selectByExample(poetryContentExample);
                        for(int i= 0;i<5;i++){
                            poetrys.add(poetryContentList.get(i));
                        }
                    }
                    if(poetrys.size()>40){
                        break;
                    }

                }
                return poetrys;
            }

        return poetrys;
    }

    @Override
    public List<PoetryContent> getPoetryByAuthorId(Long authorId) {
        PoetryContentExample poetryContentExample = new PoetryContentExample();
        poetryContentExample.createCriteria().andAuthorIdEqualTo(authorId);
        List<PoetryContent> poetryContentList = poetryContentMapper.selectByExample(poetryContentExample);
        if(poetryContentList.size()>0){
            if(poetryContentList.size()>40){
                System.out.println("niaho1");
                return poetryContentList.subList(0,40);

            }
            System.out.println("nihao2");
            return poetryContentList;
        }
        System.out.println("nihao3");
        return poetryContentList;

    }

    @Override
    public RecommendListVo getPoetryByPoetryId(Long poetryId) {
       PoetryContent poetry =poetryContentMapper.selectByPrimaryKey(poetryId);
        RecommendListVo recommendListVo = new RecommendListVo();
        AuthorExample authorExample = new AuthorExample();
        authorExample.createCriteria().andAuthorNameEqualTo(poetry.getAuthor());
        List<Author> authors = authorMapper.selectByExample(authorExample);
        if(authors.size()>0){
            recommendListVo.setDynasty(authors.get(0).getAuthorDynasty());
        }
        recommendListVo.setPoetryName(poetry.getPoetryName());
        recommendListVo.setPoetryContent(poetry.getPoetryContent());
        recommendListVo.setPoetryTranslate(poetry.getPoetryTranslate());
        recommendListVo.setPoetryBackground(poetry.getPoetryBackground());
        recommendListVo.setAuthor(poetry.getAuthor());
        recommendListVo.setPoetryId(poetry.getId());
        recommendListVo.setPoetryAnnotation(poetry.getPoetryAnnotation());

        return recommendListVo;

    }

    @Override
    public List<PoetryTypeRelation> getPracticePoetry(String grade) {
        PoetryTypeExample poetryTypeExample = new PoetryTypeExample();
        poetryTypeExample.createCriteria().andPoetryTypeEqualTo(grade);
        List<PoetryType> poetryTypes = poetryTypeMapper.selectByExample(poetryTypeExample);
        if(poetryTypes.size()>0){
            PoetryTypeRelationExample poetryTypeRelationExample = new PoetryTypeRelationExample();
            poetryTypeRelationExample.createCriteria().andPoetryTypeIdEqualTo(poetryTypes.get(0).getId());
            List<PoetryTypeRelation> poetryTypeRelations = poetryTypeRelationMapper.selectByExample(poetryTypeRelationExample);

            return poetryTypeRelations;


            }


        List<PoetryTypeRelation> list = new ArrayList<>();
            return list;
    }
}
