package com.graduation.poetry.portal.service;

import com.graduation.poetry.model.Message;
import com.graduation.poetry.model.User;
import com.graduation.poetry.model.UserFriendRelation;
import com.graduation.poetry.portal.model.dto.SendMessageParam;

import java.util.List;

public interface FriendService {


    /**
     * 将用户发送的消息存入数据库
     * @param sendMessageParam 用户发送的消息对象
     * @return 返回1代表存储成功
     */

    int sendMessage(SendMessageParam sendMessageParam);

    /**
     * 从数据库中返回用户和好友的聊天记录
     * @param userId 用户id
     * @param friendId 好友id
     * @return返回聊天对象列表
     */
    List<Message> getUserMessageById(Long userId,Long friendId);


    /**
     * 获取用户好友列表
     * @return 返回好友列表
     */
    List<User> getFriendList();


    /**
     * 搜索用户
     * @param userName 用户名
     * @return 返回用户对象
     */
    User searchFriend(String userName);

    /**
     * 分享诗词接口
     * @param poetryId 诗词id
     * @param friendId 好友id
     * @return 成功返回1，失败返回0
     */
    int sharePoetry(Long poetryId,Long friendId);
}
