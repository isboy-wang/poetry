package com.graduation.poetry.portal.controller;


import com.graduation.poetry.common.api.CommonResult;
import com.graduation.poetry.portal.service.SentenceService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;
@CrossOrigin
@Api(value = "SentenceController",description="名句接口")
@RestController
@RequestMapping("/sentence")
public class SentenceController {
    @Autowired
    private SentenceService sentenceService;

    @ApiOperation("随机返回六个名句")
    @GetMapping("/randomSentence")
    public CommonResult<Map<String,String>> randomSentence(){
        Map<String, String> sentenceMap = sentenceService.randomSentence();
        if(!CollectionUtils.isEmpty(sentenceMap)){
            return CommonResult.success(sentenceMap,"返回成功");
        }
        return CommonResult.failed("返回失败");
    }
}
