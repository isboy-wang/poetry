package com.graduation.poetry.portal.service;

import com.graduation.poetry.model.PoetryDiscuss;
import com.graduation.poetry.portal.model.dto.CommentParam;
import com.graduation.poetry.portal.model.vo.CommentUserVo;

import java.util.List;

public interface PoetryCommentService {
    /**
     *记录诗词评论
     * @param comment 诗词评论对象
     * @return 返回1表示成功，0表示失败
     */
    int recordComment(CommentParam comment);


    /**
     * 获取诗词评论列表
     * @param poetryId 诗词id
     * @return 返回诗词评论列表（不包括回复，当用户点全部回复的时候，再请求）
     */
    List<CommentUserVo> getCommentList(Long poetryId);


    /**
     * 获取评论回复列表
     * @param commentId 评论id
     * @return 返回回复列表
     */
    List<CommentUserVo> getReplyList(Long commentId);

    /**
     * 点赞接口
     * @param commentId 评论id
     * @return 1表示成功 0表示失败
     */
    int support(Long commentId);


    /**
     * 举报接口（同时举报用户和评论）
     * @param commentId 评论id
     * @param userId 用户id
     * @return 成功返回1，失败返回0
     */
    int report(Long commentId,Long userId);


}
