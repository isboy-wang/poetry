package com.graduation.poetry.portal.controller;

import com.graduation.poetry.common.api.CommonResult;
import com.graduation.poetry.model.Message;
import com.graduation.poetry.model.User;
import com.graduation.poetry.portal.model.dto.SendMessageParam;
import com.graduation.poetry.portal.service.FriendService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin
@Api(value = "FriendController",description = "好友接口")
@RestController
@RequestMapping("/friend")
public class FriendController {

    @Autowired
    private FriendService friendService;

    @ApiOperation("发送信息接口")
    @PostMapping("sendMessage")
    public CommonResult<Integer> sendMessage(@ApiParam("发送消息对象")@RequestBody SendMessageParam sendMessageParam){
        int i = friendService.sendMessage(sendMessageParam);
        if(i>0){
            return CommonResult.success(i,"保存成功");
        }
        return CommonResult.failed("保存失败");
    }


    @ApiOperation("返回用户聊天记录接口")
    @PostMapping("/getUserMessageById")
    public CommonResult<List<Message>> getUserMessageById(@ApiParam("用户id")@RequestParam("userId") Long userId,
                                                          @ApiParam("好友id")@RequestParam("friendId") Long friendId){
        List<Message> messages = friendService.getUserMessageById(userId, friendId);
        if(messages.size()>0){
            return CommonResult.success(messages,"查询成功");
        }
        return CommonResult.failed("返回失败");

    }

    @ApiOperation("获取用户好友列表")
    @GetMapping("/getFriendList")
    public CommonResult<List<User>> getFriendList(){
        List<User> friendList = friendService.getFriendList();
        if(friendList.size()>0){
            return CommonResult.success(friendList,"查询成功");
        }
        return CommonResult.failed("暂无好友");
    }

    @ApiOperation("搜索好友")
    @PostMapping("/searchFriend")
    public CommonResult<User> searchFriend(@ApiParam("用户名")@RequestParam("userName") String userName){
        User user = friendService.searchFriend(userName);
        if(user!=null){
            return CommonResult.success(user,"查询成功");
        }
        return CommonResult.failed("找不到用户");
    }


    @ApiOperation("分享诗词")
    @PostMapping("/sharePoetry")
    public CommonResult<Integer> sharePoetry(@ApiParam("诗词id")@RequestParam("poetryId")Long poetryId,
                                             @ApiParam("好友id")@RequestParam("friendId")Long friendId){
        int i = friendService.sharePoetry(poetryId, friendId);
        if(i==1){
            return CommonResult.success(1,"分享成功");
        }
        return CommonResult.failed("分享失败");

    }

}
