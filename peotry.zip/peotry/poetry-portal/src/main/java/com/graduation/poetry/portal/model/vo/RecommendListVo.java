package com.graduation.poetry.portal.model.vo;

import io.swagger.annotations.ApiModelProperty;

public class RecommendListVo {
    @ApiModelProperty(value = "诗词id")
    private Long poetryId ;

    @ApiModelProperty(value = "诗词作者朝代")
    private String dynasty ;

    @ApiModelProperty(value = "作者名字")
    private String author;

    @ApiModelProperty(value = "诗词名字")
    private String poetryName;

    @ApiModelProperty(value = "诗词内容")
    private String poetryContent;

    public Long getPoetryId() {
        return poetryId;
    }

    public void setPoetryId(Long poetryId) {
        this.poetryId = poetryId;
    }

    @ApiModelProperty(value = "诗词翻译")
    private String poetryTranslate;

    @ApiModelProperty(value = "诗词注释")
    private String poetryAnnotation;

    @ApiModelProperty(value = "创作背景")
    private String poetryBackground;

    public String getDynasty() {
        return dynasty;
    }

    public void setDynasty(String dynasty) {
        this.dynasty = dynasty;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getPoetryName() {
        return poetryName;
    }

    public void setPoetryName(String poetryName) {
        this.poetryName = poetryName;
    }

    public String getPoetryContent() {
        return poetryContent;
    }

    public void setPoetryContent(String poetryContent) {
        this.poetryContent = poetryContent;
    }

    public String getPoetryTranslate() {
        return poetryTranslate;
    }

    public void setPoetryTranslate(String poetryTranslate) {
        this.poetryTranslate = poetryTranslate;
    }

    public String getPoetryAnnotation() {
        return poetryAnnotation;
    }

    public void setPoetryAnnotation(String poetryAnnotation) {
        this.poetryAnnotation = poetryAnnotation;
    }

    public String getPoetryBackground() {
        return poetryBackground;
    }

    public void setPoetryBackground(String poetryBackground) {
        this.poetryBackground = poetryBackground;
    }

    public RecommendListVo() {
    }
}
