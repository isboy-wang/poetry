package com.graduation.poetry.enums;

import com.graduation.poetry.common.api.IErrorCode;

public enum CollectResult implements IErrorCode {
    SUC_COLLECT(0,"收藏成功"),
    CAN_COLLECT(1,"取消收藏"),
    NOT_LOGIN(2,"未登录");



    private long code;
    private String message;

    CollectResult(long code, String message) {
        this.code = code;
        this.message = message;
    }

    @Override
    public long getCode() {
        return 0;
    }

    @Override
    public String getMessage() {
        return null;
    }
}
