package com.graduation.poetry.portal.model.vo;

import io.swagger.annotations.ApiModelProperty;

import java.util.Date;

public class CollectVo {
    @ApiModelProperty("诗词名字")
    private String poetryName;
    @ApiModelProperty("诗词内容")
    private String poetryContent;
    @ApiModelProperty("收藏时间")
    private Date collectTime;
    @ApiModelProperty("诗词作者")
    private String author;
    @ApiModelProperty("诗词id")
    private Long poetryId;

    public CollectVo() {
    }

    @Override
    public String toString() {
        return "CollectVo{" +
                "poetryName='" + poetryName + '\'' +
                ", poetryContent='" + poetryContent + '\'' +
                ", collectTime=" + collectTime +
                ", author='" + author + '\'' +
                ", poetryId=" + poetryId +
                '}';
    }

    public String getPoetryName() {
        return poetryName;
    }

    public void setPoetryName(String poetryName) {
        this.poetryName = poetryName;
    }

    public String getPoetryContent() {
        return poetryContent;
    }

    public void setPoetryContent(String poetryContent) {
        this.poetryContent = poetryContent;
    }

    public Date getCollectTime() {
        return collectTime;
    }

    public void setCollectTime(Date collectTime) {
        this.collectTime = collectTime;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public Long getPoetryId() {
        return poetryId;
    }

    public void setPoetryId(Long poetryId) {
        this.poetryId = poetryId;
    }
}
