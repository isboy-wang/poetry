package com.graduation.poetry.portal.dao;


import com.graduation.poetry.model.PoetryContent;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface PoetryMapper {
     /**
      * 根据keyword查询到诗词名字包括keyword的诗词
      * @param keyword
      * @return 返回查询到的所有诗词
      */
     List<PoetryContent> getPoetryByKeyword(String keyword);
}
