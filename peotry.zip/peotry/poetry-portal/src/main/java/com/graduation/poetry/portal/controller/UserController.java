package com.graduation.poetry.portal.controller;


import com.github.pagehelper.PageInfo;
import com.graduation.poetry.common.api.CommonResult;
import com.graduation.poetry.common.utils.FileUtil;
import com.graduation.poetry.enums.CollectResult;
import com.graduation.poetry.enums.RecordBrowsingResult;
import com.graduation.poetry.enums.RegisterResult;
import com.graduation.poetry.model.PoetryContent;
import com.graduation.poetry.model.UserCollect;
import com.graduation.poetry.portal.model.dto.UserMessageParam;
import com.graduation.poetry.portal.model.dto.UserRegisterParam;
import com.graduation.poetry.portal.model.vo.CollectVo;
import com.graduation.poetry.portal.model.vo.RecommendListVo;
import com.graduation.poetry.portal.service.UserService;
import com.graduation.poetry.portal.util.SecurityUtils;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.Map;

@CrossOrigin
@Api(value = "UserController",description = "用户接口")
@RestController
@RequestMapping("/user")
public class UserController {

    @Autowired
    private UserService userService;

    @ApiOperation("用户注册")
    @PostMapping("/register")
    public CommonResult<Integer> register(@ApiParam("注册对象") @RequestBody UserRegisterParam param){
        System.out.println("------------------------------------------");
        RegisterResult register = userService.register(param);
        if (register == RegisterResult.REG_SUCCESS){
            return CommonResult.success(1,register.getMessage());
        }
        return CommonResult.failed(register.getMessage());
    }

    @ApiOperation("用户登录")
    @PostMapping("/login")
    public CommonResult<Map<String,String>> login(@ApiParam("用户名")@RequestParam("userName") String userName,
                                                  @ApiParam("密码")@RequestParam("password") String password){
        Map<String,String> login = userService.login(userName,password);
        if(!CollectionUtils.isEmpty(login)){
            return CommonResult.success(login,"登录成功");
        }
        return CommonResult.failed("登录失败");

    }
    @ApiOperation("记录用户喜好")
    @PostMapping("/recordLike")
    public CommonResult<Integer> recordLike(@ApiParam("作者Id")@RequestParam("authorId") Long authorId,
                                           @ApiParam("朝代Id")@RequestParam("dynastyId") Long dynastyId){
        if(userService.recordLike(authorId,dynastyId) == 1){
            return CommonResult.success(1,"记录成功");
        }
        return CommonResult.failed("记录失败");


    }

    @ApiOperation("返回十个推荐诗词")
    @GetMapping("/recommend")
    public CommonResult<List<RecommendListVo>> recommend(){
        List<RecommendListVo> recommend = userService.recommend();
        if(recommend != null){
            return CommonResult.success(recommend,"请求成功");
        }
        return CommonResult.failed("请求失败");
    }

    @ApiOperation("记录用户浏览记录")
    @PostMapping("/recordBrowsing")
    public CommonResult<Integer> recordBrowsing(@ApiParam("诗词Id")@RequestParam("poetryId")Long poetryId){
        RecordBrowsingResult recordBrowsingResult = userService.recordBrowsing(poetryId);
        if(recordBrowsingResult == RecordBrowsingResult.REC_SUCCESS){
            return CommonResult.success(1,recordBrowsingResult.getMessage());
        }
        return CommonResult.failed(recordBrowsingResult.getMessage());
    }

    @ApiOperation("用户收藏接口")
    @PostMapping("/collectPoetry")
    public CommonResult<Integer> collectPoetry(@ApiParam("诗词id")@RequestParam("poetryId") Long poetryId){
        CollectResult collectResult = userService.collectPoetry(poetryId);

        if(collectResult == CollectResult.SUC_COLLECT){
            return CommonResult.success(1,"收藏成功");
        }
        else if(collectResult == CollectResult.CAN_COLLECT){
            return CommonResult.success(2,"取消收藏");
        }
        return CommonResult.failed("收藏失败");

    }

    @ApiOperation("上传头像文件")
    @PostMapping("/uploadImgFile")
    public CommonResult<String> uploadImgFile(@ApiParam("头像文件")@RequestParam("file")MultipartFile file)throws Exception{
        Long userId = SecurityUtils.getCurrentUser().getId();
        String filePath = FileUtil.portalUploadFileByUserId(userId,file,1);
        if(filePath != null){
            return CommonResult.success(filePath,"上传成功");
        }
        return CommonResult.failed("上传文件失败，请重试");

    }

    @ApiOperation("修改个人信息")
    @PostMapping("/updateUserMessage")
    public CommonResult<Integer> updateUserMessage(@ApiParam("用户信息对象")@RequestBody UserMessageParam userMessage){
        int i = userService.updateUserMessage(userMessage);
        System.out.println("i=="+i);
        if(i==1){
            return CommonResult.success(1,"修改成功");
        }
        if(i==2)
        {
            return CommonResult.success(2,"查询不到喜好朝代或作者,将其他信息修改");
        }
        return CommonResult.failed("修改失败");

    }
    @ApiOperation("获取收藏列表")
    @GetMapping("/getCollectList")
    public CommonResult<List<CollectVo>> getCollectList(){
        List<CollectVo> collectList = userService.getCollectList();
        if(collectList.size()!= 0)
        {
            return CommonResult.success(collectList,"返回成功");
        }
        return CommonResult.failed("返回失败");
    }



}
