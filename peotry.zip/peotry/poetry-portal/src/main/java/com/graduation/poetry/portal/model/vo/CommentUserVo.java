package com.graduation.poetry.portal.model.vo;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiModelProperty;

import java.util.Date;

public class CommentUserVo {
    @ApiModelProperty("用户名")
    private String userName;
    @ApiModelProperty("用户头像路径")
    private String imgUrl;
    @ApiModelProperty("评论内容")
    private String commentContent;
    @ApiModelProperty("用户id")
    private Long userId;
    @ApiModelProperty("评论时间")
    private Date creatDate;
    @ApiModelProperty("点赞数")
    private Long supportNum;
    @ApiModelProperty("评论id")
    private Long commentId;
    @ApiModelProperty("回复id")
    private Long replyDiscussId;

    public CommentUserVo(String userName, String imgUrl, String commentContent, Long userId, Date creatDate, Long supportNum, Long commentId) {
        this.userName = userName;
        this.imgUrl = imgUrl;
        this.commentContent = commentContent;
        this.userId = userId;
        this.creatDate = creatDate;
        this.supportNum = supportNum;
        this.commentId = commentId;
    }

    public Long getReplyDiscussId() {
        return replyDiscussId;
    }

    public void setReplyDiscussId(Long replyDiscussId) {
        this.replyDiscussId = replyDiscussId;
    }

    public CommentUserVo() {
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getImgUrl() {
        return imgUrl;
    }

    public void setImgUrl(String imgUrl) {
        this.imgUrl = imgUrl;
    }

    public String getCommentContent() {
        return commentContent;
    }

    public void setCommentContent(String commentContent) {
        this.commentContent = commentContent;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public Date getCreatDate() {
        return creatDate;
    }

    public void setCreatDate(Date creatDate) {
        this.creatDate = creatDate;
    }

    public Long getSupportNum() {
        return supportNum;
    }

    public void setSupportNum(Long supportNum) {
        this.supportNum = supportNum;
    }

    public Long getCommentId() {
        return commentId;
    }

    public void setCommentId(Long commentId) {
        this.commentId = commentId;
    }

    @Override
    public String toString() {
        return "CommentUserVo{" +
                "userName='" + userName + '\'' +
                ", imgUrl='" + imgUrl + '\'' +
                ", commentContent='" + commentContent + '\'' +
                ", userId=" + userId +
                ", creatDate=" + creatDate +
                ", supportNum=" + supportNum +
                ", commentId=" + commentId +
                '}';
    }
}
