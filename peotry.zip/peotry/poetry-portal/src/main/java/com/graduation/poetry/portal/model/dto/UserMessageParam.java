package com.graduation.poetry.portal.model.dto;


import io.swagger.annotations.ApiModelProperty;

public class UserMessageParam {
    @ApiModelProperty("用户名")
    private String userName;
    @ApiModelProperty("用户个人简介")
    private String userIntroduce;
    @ApiModelProperty("用户头像路径")
    private String imgUrl;
    @ApiModelProperty("生日")
    private String birthday;
    @ApiModelProperty("用户性别（0表示女，1表示男")
    private int gender;
    @ApiModelProperty("用户喜欢作者")
    private String poetry_author;
    @ApiModelProperty("用户喜欢朝代")
    private String poetry_dynasty;
    @ApiModelProperty("学历")
    private String education_background;

    public UserMessageParam() {
    }

    @Override
    public String toString() {
        return "UserMessageParam{" +
                "userName='" + userName + '\'' +
                ", userIntroduce='" + userIntroduce + '\'' +
                ", imgUrl='" + imgUrl + '\'' +
                ", birthday='" + birthday + '\'' +
                ", gender=" + gender +
                ", poetry_author='" + poetry_author + '\'' +
                ", poetry_dynasty='" + poetry_dynasty + '\'' +
                ", education_background='" + education_background + '\'' +
                '}';
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserIntroduce() {
        return userIntroduce;
    }

    public void setUserIntroduce(String userIntroduce) {
        this.userIntroduce = userIntroduce;
    }

    public String getImgUrl() {
        return imgUrl;
    }

    public void setImgUrl(String imgUrl) {
        this.imgUrl = imgUrl;
    }

    public String getBirthday() {
        return birthday;
    }

    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }

    public int getGender() {
        return gender;
    }

    public void setGender(int gender) {
        this.gender = gender;
    }

    public String getPoetry_author() {
        return poetry_author;
    }

    public void setPoetry_author(String poetry_author) {
        this.poetry_author = poetry_author;
    }

    public String getPoetry_dynasty() {
        return poetry_dynasty;
    }

    public void setPoetry_dynasty(String poetry_dynasty) {
        this.poetry_dynasty = poetry_dynasty;
    }

    public String getEducation_background() {
        return education_background;
    }

    public void setEducation_background(String education_background) {
        this.education_background = education_background;
    }
}
