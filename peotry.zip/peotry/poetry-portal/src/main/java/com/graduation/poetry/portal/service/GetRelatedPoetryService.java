package com.graduation.poetry.portal.service;

import com.graduation.poetry.model.PoetryContent;
import com.graduation.poetry.model.PoetryTypeRelation;
import com.graduation.poetry.portal.model.vo.RecommendListVo;

import java.util.List;

public interface GetRelatedPoetryService {


    /**
     * 根据传入的关键字，查询可能相关的诗词
     * @param keyword
     * @return返回查询到的诗词
     */
    List<PoetryContent> searchPoetry(String keyword);


    /**
     *
     * 根据诗词朝代id获取诗词
     * @param dynasty 朝代id
     * @return返回诗词列表
     */
    List<PoetryContent> getPoetryByDynastyId(String dynasty);


    /**
     * 根据诗词作者id获取作者诗词
     * @param authorId 作者id
     * @return 返回诗词列表
     */
    List<PoetryContent> getPoetryByAuthorId(Long authorId);

    /**
     * 获取诗词内容，根据诗词id
     * @param poetryId 诗词id
     * @return返回诗词对象
     */
    RecommendListVo getPoetryByPoetryId(Long poetryId);


    /**
     * 获取练习诗词
     * @param grade 用户年级
     * @return 返回练习诗词列表
     */
    List<PoetryTypeRelation> getPracticePoetry(String grade);




}
