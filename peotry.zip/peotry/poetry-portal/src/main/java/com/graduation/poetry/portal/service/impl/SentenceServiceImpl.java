package com.graduation.poetry.portal.service.impl;

import com.graduation.poetry.mapper.FamousSentenceMapper;
import com.graduation.poetry.model.FamousSentence;
import com.graduation.poetry.model.FamousSentenceExample;
import com.graduation.poetry.portal.service.SentenceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

@Service
public class SentenceServiceImpl implements SentenceService {
    @Autowired
    private FamousSentenceMapper famousSentenceMapper;
    @Override
    public Map<String, String> randomSentence() {
        Map<String,String> sentenceMap = new HashMap<>();
        Random random = new Random();//默认构造方法
        int randomId = random.nextInt(238);
        if(randomId >232){
            randomId = 232;
        }


        for(int i = 0; i<6;i++){
            long id = randomId+ i;
            FamousSentenceExample famousSentenceExample = new FamousSentenceExample();
            famousSentenceExample.createCriteria().andIdEqualTo(id);
            FamousSentence famousSentence = famousSentenceMapper.selectByExample(famousSentenceExample).get(0);//从数据库中找到名句对象
            String sentence =famousSentence.getFamousSentence();//提取出句子
            String source = famousSentence.getSourceBook();
            sentenceMap.put(sentence,source);

        }
    return sentenceMap;
    }
}
