package com.graduation.poetry.portal.util;


import com.graduation.poetry.model.User;
import com.graduation.poetry.portal.model.PortalUserDetails;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;


//从当前安全框架里取出当前用户的信息
public class SecurityUtils {

    public static final Logger logger = (Logger) LoggerFactory.getLogger(SecurityUtils.class);
    public static User getCurrentUser(){
        SecurityContext context = SecurityContextHolder.getContext();
        Authentication authentication = context.getAuthentication();
        if(authentication.getPrincipal() instanceof String){
            logger.info("用户匿名登录，登录名为"+authentication.getPrincipal());
            return null;
        }
        PortalUserDetails portalUserDetails = (PortalUserDetails) authentication.getPrincipal();
        return portalUserDetails.getUser();
    }
}
