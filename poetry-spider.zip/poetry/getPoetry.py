# -*- codeing =utf-8 -*-
#  time: 2021/10/16
import re

from bs4 import BeautifulSoup
import poetrySpider
#正则表达式
findPoetryUrl =re.compile(r'<p><a href="(.*?)" style="font-size:18px')#获取诗词详情链接
findPoetryName = re.compile(r'<h1 style="font-size:20px; line-height:22px; height:22px; margin-bottom:10px;">(.*?)</h1>')#获取诗词名称
findAuther = re.compile(r'.aspx">(.*?)</a> <a href="https://so.gushiwen.cn')#获取诗词作者
findDynasty = re.compile(r'">〔(.*?)〕</a></p>')#获取诗词朝代
findContent = re.compile(r'〕</a></p>\n<div class="contson" id="contson(.*?)\n</div>\n</div>',re.S)#获取正文
findCheckAll = re.compile(r'fanyiquan(.*?)</div>')#找有没有fangyiquan,确认需不需要展开
findtranslation = re.compile(r'<p>.*译.*</strong>(.*?)</p>',re.S)#查看全文的翻译
findtranslation1 = re.compile(r'<p><strong>.*译.*</strong>(.*?)</p>\n<p>',re.S)#查看需要展开全文的翻译
findCheckBgAll =re.compile(r'shangxiquan(.*?)</div>')#找有没有shangxiquan,确认需不需要展开
findAnnotation = re.compile(r'<p>.*注释.*</strong>(.*?)</p>',re.S)#查看注释
findIdjm = re.compile(r'href="javascript:fanyiShow\(.+,(.*?)\)" style="text-decoration:none;">展开阅读全文 ∨</a></div>')#获取翻译展开内容的id
findBgIdjm = re.compile(r'href="javascript:fanyiShow\(.+,(.*?)\)" style="text-decoration:none;">展开阅读全文 ∨</a></div>')#获取翻译展开内容的id
findRemove = re.compile(r'<a (.*?)>')#查找要删除的链接
findBgid = re.compile(r'创作背景</span></h2>\n<a href="javascript:PlayShangxi(.*?)http://so.gushiwen.cn/',re.S)#获取创作背景模块的id
findBg  = re.compile(r'<p>(.*?)</p>')

#全局变量

generalBaseUrl = 'https://so.gushiwen.cn'
expandUrl = '&page='
allTranslation = '/nocdn/ajaxfanyi.aspx?id='
#获取诗词列表并保存
def getPoetryList(poetryUrlList):
    for item in poetryUrlList:
        baseUrl = item[1]#作者的诗词链接
        authorId = item[0]
        print('作者',authorId)
        poetryList = getAllPoetry(baseUrl,authorId)
        # print(poetryList)
        poetrySpider.savePoetryMessage(poetryList)


#获取作者所有诗词
def getAllPoetry(baseUrl,authorId):
    poetryList = []
    baseUrl = baseUrl+ "&page="
    #循环获取作者每一页的诗词
    for  i in range(1,11):
        url = baseUrl + str(i)
        html = poetrySpider.askUrl(url)
        if html == '':
            html = poetrySpider.askUrl(url)
            if html == '':
                continue

        soup = BeautifulSoup(html, "html.parser")
        sons = soup.find_all('div', class_='sons')
        #循环获取一页中的每个诗词
        for i in range(len(sons)-5):#每页都会多出五个sons，所以剪五
            sons[i] = str(sons[i])
            url =generalBaseUrl+ re.findall(findPoetryUrl,sons[i])[0]
            contentList = getPoetryContent(url,authorId)
            poetryList.append(contentList)#将诗词添加到诗词列表中

    return poetryList





#获取一个界面的诗词详情(返回：诗词内容列表）
def getPoetryContent(poetryUrl,authorId):
    html = poetrySpider.askUrl(poetryUrl)
    soup = BeautifulSoup(html, "html.parser")
    cont = soup.find_all('div', class_='left')[1]
    cont = str(cont)
    #查找诗词名
    poetryName = re.findall(findPoetryName,cont)[0]

    # print(poetryName)
    #查找诗词作者
    poetryAuthor = re.findall(findAuther,cont)
    if(len(poetryAuthor) == 0):
        poetryAuthor = ''
    else:
        poetryAuthor = poetryAuthor[0]
    # print(poetryAuthor)#诗词作者
    #查找诗词正文内容
    poetryCont = re.findall(findContent,cont)[0]
    poetryCont = poetryCont[15:]
    poetryCont = re.sub(r"<.*?>", "", poetryCont)

    poetryCont = re.sub(r'\n+', '', poetryCont)
    # print(poetryCont) #诗词内容

    #查找是否有查看全文模块

    checkAll = re.findall(findCheckAll,cont)
    if len(checkAll) != 0 :#是否有全文模块
        idjm = re.findall(findIdjm,cont)[0]
        idjm  = idjm.strip("'")
        traHtml = poetrySpider.askUrl(generalBaseUrl+allTranslation+idjm)
        traSoup = BeautifulSoup(traHtml,'html.parser')
        tracont = str(traSoup)
        if len(re.findall(findtranslation,tracont)) != 0:#是否有翻译
            translation = re.findall(findtranslation,tracont)[0]

        else:
            translation = ''


        if len(re.findall(findAnnotation, tracont)) != 0:  # 是否有注释

            annotation = re.findall(findAnnotation, tracont)[0]

        else:
            annotation = ''


    else:#没有全文模块
        if len(re.findall(findtranslation,cont)) != 0:

            translation = re.findall(findtranslation,cont)[0]
        else:
            translation = ''

        if len(re.findall(findAnnotation,cont)) != 0:
            annotation = re.findall(findAnnotation,cont)[0]
        else:
            annotation = ''


    translation =re.sub(r"<.*?>","",translation)  # 删除链接



    annotation =re.sub(r"<.*?>","",annotation)  # 删除链接


    # print('翻译：'+translation)
    # print('注释：'+annotation)

    #查找是否有查看创作背景全文模块
    bg = ''
    if '创作背景' in cont:#有没有创作背景
        #找到id

        bgId = re.findall(findBgid,cont)
        if len(bgId) >0:#有没有找到创作背景

            bgId = bgId[0][1:]
            bgId = bgId.strip("'")
            bgId = bgId.strip(',')

            if 'id="shangxi'+bgId+'"' in cont:#有展开模块（有展开模块就会有shangxi+id）
                bgCont = soup.find_all('div', id='shangxi'+bgId)[0]
                bgCont = str(bgCont)
            else:#没有展开模块
                bgCont = soup.find_all('div', class_ = 'contyishang')
                for originalBg in bgCont:
                    if '创作背景' in str(originalBg):#挨个判断是不是创作背景
                        bgCont = originalBg
                    else:
                        bgCont = ''
            bgCont = str(bgCont)
            bg = re.findall(findBg,bgCont)
            if len(bg) != 0:
                if(len(bg[0]) > 2):
                    bg = bg[0][2:]
                    bg = re.sub(r"<.*?>", "", bg)
                else:
                    bg = ''

            # print(bg)

        else:
            print("找不到id")
    else:
        bg = ''
        # print("找不到创作背景")
        # print(cont)

    contentList = []
    contentList.append(authorId)#作者id
    contentList.append(poetryName)#诗词名
    contentList.append(poetryAuthor)#诗词作者名
    contentList.append(poetryCont)#诗词内容
    contentList.append(translation)#翻译
    contentList.append(annotation)#注释
    contentList.append(bg)#创作背景
    # print(contentList)
    return contentList