# -*- codeing =utf-8 -*-
#  time: 2021/10/16

import re
from bs4 import BeautifulSoup
import poetrySpider
'''
param: 作者朝代列表（包括名字，朝代，作者详情链接）
return: 作者详情列表（包括作者朝代,名字，简介，诗文篇数，作者头像链接，所有诗词链接）
'''

#正则表达式：
findAuthorName = re.compile(r'<b>(.*?)</b></a>',re.S)    #获取作者名
findAuthorBackground = re.compile(r'<p style=" margin:0px;">(.*?)<a href="',re.S)#背景
# findAuthorImg = re.compile(r'src="(.*?)',re.S)#图片链接
findAllPoetry = re.compile(r'<a href="(.*?)">►')#诗词链接
findPoetryNum = re.compile(r'">►(.*?)篇诗文</a>')
findAuthorImg = re.compile(r'src="(.*?)"')
#传入朝代列表，返回作者列表

#全局变量
dataList = []

#获取一个作者的信息
def getAuthorMessage(html,item):
    # print(item)
    soup = BeautifulSoup(html, "html.parser")
    message  = soup.find_all('div', class_='sonspic')[0]
    message = str(message)
    #         # print(item)
    #         #找到并添加诗词作者的名字
    #         authorName=re.findall(findAuthorName,item)[0]
    #
    #
    #         data.append(authorName)
    #找到并添加诗词作者的背景
    AuthorBackground = re.findall(findAuthorBackground,message)[0]
    # print(item)
    item.append(AuthorBackground)
    #找到并添加作者的所有诗词链接
    allPoetryLink = re.findall(findAllPoetry,message)[0]

    allPoeUrl = 'https://so.gushiwen.cn'
    poeurl = allPoeUrl+allPoetryLink
    item.append(poeurl)
    #找到并添加诗词作者的画像
    authorImgLink = re.findall(findAuthorImg,message)

    if len(authorImgLink)!= 0:
        item.append(authorImgLink[0])
    else:
        item.append("  ")

    #找到并添加作者的诗词数量
    poetryNum = re.findall(findPoetryNum,message)
    if len(poetryNum)!=0:
        item.append(poetryNum[0])
    else:
        item.append(" ")
    return item


#获取所有作者的信息并返回
def getData(dynList):

    for item in dynList:
        html = poetrySpider.askUrl(str(item[0]))
        data = getAuthorMessage(html,item)
        dataList.append(data)



    return dataList

