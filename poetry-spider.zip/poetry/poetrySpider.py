# -*- codeing =utf-8 -*-
#  time: 2021/10/16



import re
from bs4 import BeautifulSoup
import urllib.error,urllib.request
import getAuthor
import pymysql
import datetime
import getPoetry
import getSentence
#全局变量
dynastyList= []
dataList = []
authorList = []
Time = datetime.datetime.now()  #获取现在时间
def main():
#获取朝代列表（爬取作者）
    # baseUrl = "https://so.gushiwen.cn/authors/default.aspx?p="
    # #获取作者朝代列表
    # html = askUrl(baseUrl+'1')
    # dynastyList = AuthorDynasty(html)
    # authorList = getAuthor.getData(dynastyList)
    # saveAuthorMessage(authorList)
#获取一个网页的源代码（爬取所有诗词）
    # poetryUrl = getPoetryUrl()
    # getPoetry.getPoetryList(poetryUrl)
    # savePoetryMessage(poetryList)
    # html = askUrl('https://so.gushiwen.cn/shiwenv_ca9eaf40a6ce.aspx')
    # print(html)
#爬取名句
    getSentence.getAllSentence()





def askUrl(url):
    head={"user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.54 Safari/537.36 Edg/95.0.1020.30",'cookie': 'login=flase; wxopenid=defoaltid; Hm_lvt_9007fab6814e892d3020a64454da5a55=1639297812,1639365303,1639385776,1639392544; ASP.NET_SessionId=myfcejxfqxo0y3ob0s5051gv; Hm_lpvt_9007fab6814e892d3020a64454da5a55=1639402475'
    }
    html = ''
    request = urllib.request.Request(url, headers=head)
    try:

        response = urllib.request.urlopen(request)
        html = response.read().decode("utf-8")
    except urllib.error.URLError as e:
        if hasattr(e,"reason"):
            print(e.reason)
    except:
        print("又报错了")
    return html

#获取作者朝代列表正则表达式

#获取作者详情链接
findAutLink = re.compile(r'<a href="(.*?)" target="_blank">')
findAutName = re.compile(r'target="_blank">(.*?)</a>')
findAutDynasty = re.compile(r'</a>\((.*?)\)')
findList = re.compile(r'<span>(.*?)</span>')

#获取作者朝代列表
def AuthorDynasty(html):

    htmlsoup = BeautifulSoup(html, "html.parser")
    authorDynasty = htmlsoup.find_all('div', id='leftLuesuo')
    authorDynasty = str(authorDynasty)
    list = re.findall(findList,authorDynasty)

    for item in list:
        data =[]
        #获取作者详情页链接
        autLink = re.findall(findAutLink,item)[0]

        data.append("https://so.gushiwen.cn"+autLink)

        #获取作者姓名
        autName = re.findall(findAutName,item)[0]
        data.append(autName)

        #获取作者朝代
        autDynasty =re.findall(findAutDynasty,item)[0]
        data.append(autDynasty)

        dynastyList.append(data)
    return dynastyList

#保存作者数据
def saveAuthorMessage(authorList):
    conn = pymysql.connect(host="localhost" ,user="root" ,password="wct240450" ,port=3306 , database="poetry" , charset="utf8" )

    #获取游标
    cursor = conn.cursor()

    #编写sql语句

    # conn.commit()
    # cursor.execute(sql);
    for item in authorList:
        print([item[1], item[3], item[2], item[6], item[5], item[4]])
        sql = '''
        insert into author(author_name,author_background,author_dynasty,poetry_number,author_img,poetry_url,create_time,update_time) values('%s','%s','%s','%s','%s','%s','%s','%s')\

        '''%(item[1] ,item[3], item[2], item[6], item[5], item[4],Time,Time)


        try:

            cursor.execute(sql);
            print("保存成功")
            conn.commit()
        except Exception as e:
            conn.rollback()
            print("操作失败")

    cursor.close()
    conn.close()
#保存诗词
def savePoetryMessage(poetryList):
    #连接数据库
    conn = pymysql.connect(host="localhost" ,user="root" ,password="wct240450" ,port=3306 , database="poetry" , charset="utf8" )

    #获取游标
    cursor = conn.cursor()

    #编写sql语句

    # conn.commit()
    # cursor.execute(sql);
    for item in poetryList:
        # print([item[0] ,item[2] ,item[1], item[3], item[4], item[5], item[6],Time,Time])
        sql = '''
        insert into poetry_content(author_id,author,poetry_name,poetry_content,poetry_translate,poetry_annotation,poetry_background,create_time,update_time) values('%s','%s','%s','%s','%s','%s','%s','%s','%s')\

        '''%(item[0] ,item[2] ,item[1], item[3], item[4], item[5], item[6],Time,Time)


        try:

            cursor.execute(sql);
            print("保存成功")
            conn.commit()
        except Exception as e:
            print(Exception)
            conn.rollback()
            print("操作失败")

    cursor.close()
    conn.close()

#保存名句
def saveSentence(sentenceList):
    #连接数据库
    conn = pymysql.connect(host="localhost" ,user="root" ,password="wct240450" ,port=3306 , database="poetry" , charset="utf8" )

    #获取游标
    cursor = conn.cursor()

    #编写sql语句

    # conn.commit()
    # cursor.execute(sql);
    for item in sentenceList:
        print(item)
        # print([item[0] ,item[2] ,item[1], item[3], item[4], item[5], item[6],Time,Time])
        sql = '''
        insert into famous_sentence(famous_sentence,source_book,create_time) values('%s','%s','%s')\

        '''%(item[0] ,item[1] ,Time)


        try:

            cursor.execute(sql);
            print("保存成功")
            conn.commit()
        except Exception as e:
            print(Exception)
            print(e)
            conn.rollback()
            print("操作失败")

    cursor.close()
    conn.close()


#根据年级分类的诗词
def saveTypePoetry(sentenceList):
    #连接数据库
    conn = pymysql.connect(host="localhost" ,user="root" ,password="wct240450" ,port=3306 , database="poetry" , charset="utf8" )

    #获取游标
    cursor = conn.cursor()

    #编写sql语句

    # conn.commit()
    # cursor.execute(sql);
    for item in sentenceList:

        sql = '''
        insert into poetry_type_relation(poetry_name,poetry_type_id,create_time,update_time,poetry_content,poetry_author) values('%s','%s','%s','%s','%s','%s')\

        '''%(item[1] ,item[0] ,Time,Time,item[3],item[2])


        try:

            cursor.execute(sql);
            print("保存成功")
            conn.commit()
        except Exception as e:
            print(Exception)
            print(e)
            conn.rollback()
            print("操作失败")

    cursor.close()
    conn.close()


#获取作者诗词链接列表
def getPoetryUrl():
    poetryUrl = ()

    conn = pymysql.connect(host="localhost" ,user="root" ,password="wct240450" ,port=3306 , database="poetry" , charset="utf8" )

    #获取游标
    cursor = conn.cursor()

    #编写sql语句

    sql = '''
    SELECT id,poetry_url FROM author
    
    '''


    try:

        cursor.execute(sql) ;
        poetryUrl = cursor.fetchall()
        # print(poetryUrl[1])
        # print(len(poetryUrl))
    except Exception as e:
        conn.rollback()
        print(e)
        print("操作失败")

    cursor.close()
    conn.close()

    return poetryUrl





if __name__ == "__main__":
    main()
