# -*- coding:utf-8 -*-
#  time:2022/3/1:13:44
#  user:不学习哪有饭吃呀！
import poetrySpider
import re
from bs4 import BeautifulSoup
import getPoetry
findPoetryUrl = re.compile(r'<span><a href="(.*?)" target="_blank">',re.S)
findPoetryName = re.compile(r'.aspx" target="_blank">(.*?)</a>',re.S)
def main():
    url = 'https://so.gushiwen.cn/gushi/gaozhong.aspx'
    html = poetrySpider.askUrl(url)
    soup = BeautifulSoup(html,"html.parser")
    sons = soup.find_all('div',class_='typecont')
    # print(sons[24])
    j = 19
    for i in range(0,4,2):#每个年级

        item = str(sons[i])
        poetryUrl = re.findall(findPoetryUrl,item)
        list = []#用来存改年级所有的诗词
        for url in poetryUrl:#年级里的每一首诗
            contentList =  getPoetry.getPoetryContent(url,j)
            list.append(contentList)
        #将列表里的诗词存到数据库
        print(list)
        poetrySpider.saveTypePoetry(list)
        j = j+1


if __name__ == "__main__":
    main()
