# -*- coding:utf-8 -*-
#  time: 2021/10/16
#  user:不学习哪有饭吃呀！
import re
a = 'abc'
i =1  #int
c= [1,2,3]
c.append(1)
print(c)
