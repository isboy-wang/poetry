# -*- coding:utf-8 -*-
#  time:2022/2/10:16:47
#  user:不学习哪有饭吃呀！

import re
from bs4 import BeautifulSoup
import poetrySpider

baseUrl = 'https://so.gushiwen.cn/mingjus/default.aspx?page='
findSentAndSource = re.compile(r'<div class="cont" style=" margin-top:12px;border-bottom:1px dashed #DAD9D1; padding-bottom:7px;">(.*?)\n</div>',re.S)
findSentence= re.compile(r'.aspx" style=" float:left;" target="_blank">(.*?)</a>\n<span style=',re.S)#获取 名句
findSentSource = re.compile(r'.aspx" style=" float:left;" target="_blank">(.*?)</a>',re.S)#获取来源
def getAllSentence():

    for i in range(1,6):
        sentenceList = []
        url = baseUrl+str(i)
        html = poetrySpider.askUrl(url)
        soup = BeautifulSoup(html, "html.parser")
        sons = soup.find_all('div', class_='sons')

        cont = str(sons[0])
        # print (cont)
        sentAndAuthor = re.findall(findSentAndSource,cont)
        for item in sentAndAuthor:

            singleSentence = []
            #获取名句
            sentence = re.findall(findSentence,item)
            if(len(sentence) == 0):
                sentence = ''
            else:
                sentence = sentence[0]
            singleSentence.append(sentence)#将名句存入单个句子列表中
            #查找名句出处
            sentSource = re.findall(findSentSource,item)

            if(len(sentSource) == 0 or len(sentSource) ==1):
                sentSource = ''
            else:
                sentSource = sentSource[1]
            singleSentence.append(sentSource)
            if(singleSentence[0]==''):
                pass
            else:
                sentenceList.append(singleSentence)

        poetrySpider.saveSentence(sentenceList)







